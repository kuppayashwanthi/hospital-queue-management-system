import React, { useState } from 'react';
import { 
  ArrowLeft, Clock, MapPin, CheckCircle2, ChevronRight, User, Phone, 
  Sparkles, AlertCircle, RefreshCw, Smartphone, Lock, ShieldCheck, QrCode, Wallet, Info, Download 
} from 'lucide-react';
import { Hospital, Department, Token } from '../types';
import { bookNewToken, calculatePositionAndWait, loadQueueState } from '../lib/queueEngine';
import { LanguageType, translations } from '../lib/translations';

interface BookTokenProps {
  hospital: Hospital;
  patientName: string;
  patientPhone: string;
  onBack: () => void;
  onTokenBooked: (token: Token) => void;
  initialDeptId?: string;
  language: LanguageType;
}

type PaymentState = 'idle' | 'payment_selection' | 'pin_entry' | 'processing' | 'success';

export default function BookToken({
  hospital,
  patientName,
  patientPhone,
  onBack,
  onTokenBooked,
  initialDeptId,
  language
}: BookTokenProps) {
  const [selectedDeptId, setSelectedDeptId] = useState<string>(
    initialDeptId || (hospital.departments.length > 0 ? hospital.departments[0].id : '')
  );
  
  // Local input states pre-filled from props
  const [patientFormName, setPatientFormName] = useState(patientName);
  const [patientFormPhone, setPatientFormPhone] = useState(patientPhone);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookedReceipt, setBookedReceipt] = useState<Token | null>(null);

  // PhonePe Payment States
  const [paymentState, setPaymentState] = useState<PaymentState>('idle');
  const [selectedMethod, setSelectedMethod] = useState<'app' | 'upi_id' | 'qr'>('app');
  const [customUpiId, setCustomUpiId] = useState('');
  const [upiPin, setUpiPin] = useState<string[]>([]);
  const [txnId, setTxnId] = useState('');
  const [paymentProcessStep, setPaymentProcessStep] = useState('Securing connection to Bank Server...');

  const t = translations[language];
  const activeDepartment = hospital.departments.find(d => d.id === selectedDeptId);

  // Price matrix based on department speciality
  const getDepartmentFee = (deptName?: string) => {
    if (!deptName) return 150;
    const name = deptName.toLowerCase();
    if (name.includes('cardio') || name.includes('heart')) return 350;
    if (name.includes('pediat') || name.includes('child')) return 200;
    if (name.includes('gyne') || name.includes('obstet')) return 250;
    if (name.includes('ortho') || name.includes('bone')) return 280;
    if (name.includes('neuro') || name.includes('brain')) return 400;
    if (name.includes('ophthal') || name.includes('eye')) return 180;
    return 150; // default consultation fee
  };

  const consultationFee = getDepartmentFee(activeDepartment?.name);

  // Read latest queue lists to show live status before booking
  const state = loadQueueState();
  const getDeptWaitStats = (deptId: string) => {
    const deptTokens = state.tokens.filter(
      t => t.hospitalId === hospital.id && t.departmentId === deptId
    );
    const waitingList = deptTokens.filter(t => t.status === 'waiting');
    const callingList = deptTokens.filter(t => t.status === 'calling');
    
    const dept = hospital.departments.find(d => d.id === deptId);
    const baseTime = dept?.baseTimeMins || 10;
    
    return {
      waitingCount: waitingList.length,
      currentServing: callingList.length > 0 ? callingList[0].tokenNumber : 'None yet',
      estimatedWaitMins: (waitingList.length + callingList.length) * baseTime
    };
  };

  const handleBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDeptId || !patientFormName.trim() || !patientFormPhone.trim()) return;

    // Generate random mock Transaction ID
    const generatedTxn = 'YBL' + Math.floor(100000000000 + Math.random() * 900000000000);
    setTxnId(generatedTxn);
    
    // Auto-generate a standard Indian secure VPA address
    const normalizedDigits = patientFormPhone.replace(/[^0-9]/g, '');
    const cleanPhone = normalizedDigits.length >= 10 ? normalizedDigits.slice(-10) : '9876543210';
    setCustomUpiId(`${cleanPhone}@ybl`);
    setUpiPin([]);
    setPaymentState('payment_selection');
  };

  // Authorize UPI Payment action
  const handleProceedToPin = () => {
    setUpiPin([]);
    setPaymentState('pin_entry');
  };

  const handleKeypadPress = (num: string) => {
    if (upiPin.length < 4) {
      setUpiPin([...upiPin, num]);
    }
  };

  const handleKeypadDelete = () => {
    if (upiPin.length > 0) {
      setUpiPin(upiPin.slice(0, -1));
    }
  };

  const handleKeypadClear = () => {
    setUpiPin([]);
  };

  const handleConfirmPayment = () => {
    setPaymentState('processing');
    setPaymentProcessStep('Verifying secure connection...');
    
    setTimeout(() => {
      setPaymentProcessStep('Decrypting secure UPI Pin code...');
      
      setTimeout(() => {
        setPaymentProcessStep('Authorizing balance check with bank...');
        
        setTimeout(() => {
          setPaymentState('success');
        }, 800);
      }, 700);
    }, 600);
  };

  // Submit and create actual queue token after PhonePe confirms
  const handleGenerateToken = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      try {
        const token = bookNewToken(
          hospital.id,
          selectedDeptId,
          patientFormName.trim(),
          patientFormPhone.trim()
        );
        setBookedReceipt(token);
        setPaymentState('idle'); // clear states back
      } catch (err) {
        console.error('Failed to book', err);
        alert('An error occurred during booking. Please try again.');
      } finally {
        setIsSubmitting(false);
      }
    }, 500);
  };

  const handleDownloadTicketFile = () => {
    if (!bookedReceipt) return;
    const estWait = calculatePositionAndWait(bookedReceipt.id).estimatedWaitMins;
    const positionStats = calculatePositionAndWait(bookedReceipt.id);
    const doctorObj = hospital.departments.find(d => d.id === bookedReceipt.departmentId);
    
    const fileContent = `================================================
          CAREQUEUE DIGITAL CLINICAL RECEIPT
================================================
TOKEN NUMBER:       \t${bookedReceipt.tokenNumber}
STATUS:             \tCONFIRMED
PATIENT NAME:       \t${bookedReceipt.patientName}
PHONE NUMBER:       \t${bookedReceipt.patientPhone}
------------------------------------------------
HOSPITAL:           \t${bookedReceipt.hospitalName}
DEPARTMENT:         \t${bookedReceipt.departmentName}
CLINICIAN:          \t${doctorObj?.doctorName || 'N/A'}
ROOM NUMBER:        \t${doctorObj?.roomNumber || 'N/A'}
------------------------------------------------
POSITION IN QUEUE:  \t#${positionStats.position + 1}
PATIENTS AHEAD:     \t${positionStats.position}
EST. WAITING TIME:  \t~ ${estWait} minutes
REGISTRATION TIME:  \t${new Date(bookedReceipt.createdAt).toLocaleTimeString()}
================================================
   THANK YOU FOR BOOKING ONLINE WITH CAREQUEUE.
   PLEASE STAY NEARBY TO ANNOUNCE ROOM CALLS.
================================================`;

    const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CareQueue_Token_${bookedReceipt.tokenNumber}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-3xl mx-auto" id="booking-container">
      {/* Back Button Link */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 px-4 py-2 bg-[#14181f]/80 text-slate-300 hover:text-white text-xs sm:text-sm font-bold border border-white/10 hover:border-cyan-500/30 rounded-xl transition-all mb-5 cursor-pointer shadow-md group"
        id="btn-back-to-hospitals"
      >
        <ArrowLeft className="h-4 w-4 text-cyan-400 group-hover:-translate-x-1 transition-transform" />
        <span>{t.return_to_facilities}</span>
      </button>

      {!bookedReceipt ? (
        /* BOOKING FORM DESIGN */
        <div className="bg-[#0f1218] rounded-3xl border border-white/5 shadow-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12">
          {/* Left panel: Selected Hospital Information */}
          <div className="md:col-span-5 bg-[#14181f] border-r border-white/5 p-6 sm:p-8 flex flex-col justify-between">
            <div className="space-y-5">
              <span className="inline-flex items-center space-x-1.5 bg-slate-900 text-slate-300 text-[10px] font-mono leading-none tracking-wider uppercase font-bold px-2.5 py-1.5 rounded-lg border border-white/10">
                Facility Overview
              </span>
              
              <div className="space-y-2">
                <h3 className="text-xl font-serif italic font-medium text-white leading-tight">
                  {hospital.name}
                </h3>
                <p className="text-xs text-slate-400 font-sans flex items-start gap-1">
                  <MapPin className="h-4 w-4 text-cyan-555 shrink-0 mt-0.5" />
                  <span>{hospital.location}</span>
                </p>
              </div>

              {/* Department Info Box */}
              {activeDepartment && (
                <div className="bg-[#0f1218] rounded-2xl p-4 border border-white/5 space-y-3 shadow-md">
                  <span className="text-[9px] uppercase font-bold font-mono tracking-wider text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/10">
                    Selected Division
                  </span>
                  <div>
                    <h4 className="font-sans font-bold text-slate-200 text-sm">{activeDepartment.name}</h4>
                    <p className="text-xs text-slate-550 font-sans mt-0.5">Consultant: {activeDepartment.doctorName}</p>
                    <p className="text-xs text-slate-550 font-sans">Location: {activeDepartment.roomNumber}</p>
                  </div>
                  
                  {/* Live wait status for department */}
                  <div className="pt-3 border-t border-white/5 space-y-1.5">
                    <div className="flex justify-between text-xs font-sans text-slate-400">
                      <span>Currently Serving:</span>
                      <span className="font-mono font-bold text-cyan-400">{getDeptWaitStats(activeDepartment.id).currentServing}</span>
                    </div>
                    <div className="flex justify-between text-xs font-sans text-slate-400">
                      <span>Waiting Ahead:</span>
                      <span className="font-bold text-slate-200">{getDeptWaitStats(activeDepartment.id).waitingCount} people</span>
                    </div>
                    <div className="flex justify-between text-xs font-sans text-slate-400">
                      <span>Estimated Wait:</span>
                      <span className="font-bold text-cyan-400 font-mono">{getDeptWaitStats(activeDepartment.id).estimatedWaitMins} mins</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-6 border-t border-white/5 hidden md:block">
              <p className="text-[11px] text-slate-500 font-sans leading-relaxed">
                By booking a CareQueue token, you secure an active position in today's clinic schedule. Keep this tab open to monitor countdown clock updates live.
              </p>
            </div>
          </div>

          {/* Right panel: Scheduling inputs Form & PhonePe Payment flow */}
          <div className="md:col-span-7 p-6 sm:p-8 flex flex-col justify-between">
            {paymentState === 'idle' ? (
              <div>
                <h3 className="text-xl font-serif italic text-white tracking-tight flex items-center gap-1.5 font-medium">
                  <Wallet className="h-5 w-5 text-cyan-400" />
                  <span>Schedule Queue Ticket</span>
                </h3>
                <p className="text-xs text-slate-400 tracking-wide mt-1">
                  Provide medical details for accurate check-in records. Consultation fee will be debited via PhonePe.
                </p>

                <form onSubmit={handleBook} className="mt-6 space-y-5" id="form-book-ticket">
                  {/* Department Dropdown Selection */}
                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">
                      Select Clinic / Department Speciality
                    </label>
                    <div className="grid grid-cols-1 gap-2">
                      {hospital.departments.map((dept) => {
                        const stats = getDeptWaitStats(dept.id);
                        const isSelected = selectedDeptId === dept.id;
                        return (
                          <button
                            type="button"
                            key={dept.id}
                            onClick={() => setSelectedDeptId(dept.id)}
                            className={`p-3 text-left rounded-xl border transition-all flex justify-between items-center cursor-pointer ${
                              isSelected
                                ? 'border-cyan-500 bg-cyan-500/5 ring-2 ring-cyan-500/5'
                                : 'border-white/5 hover:border-white/10 bg-[#14181f]/60'
                            }`}
                          >
                            <div>
                              <p className="text-xs font-sans font-bold text-slate-200">{dept.name}</p>
                              <p className="text-[10px] text-slate-500 font-sans">{dept.doctorName}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-[10.5px] font-mono font-bold text-cyan-400">{stats.estimatedWaitMins} mins wait</p>
                              <p className="text-[9px] text-slate-505 font-sans uppercase tracking-wider">{stats.waitingCount} waiting</p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Patient Name Input */}
                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">
                      Patient Full Name
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                        <User className="h-4.5 w-4.5" />
                      </span>
                      <input
                        type="text"
                        required
                        value={patientFormName}
                        onChange={(e) => setPatientFormName(e.target.value)}
                        placeholder="e.g. Timothy Vance"
                        className="w-full bg-[#14181f] border border-white/5 rounded-xl py-2.5 pl-10 pr-4 font-sans text-sm focus:border-cyan-500 focus:bg-[#1a202a] text-slate-100 outline-none transition-all placeholder-slate-500"
                        id="book-patient-name"
                      />
                    </div>
                  </div>

                  {/* Patient Phone Input */}
                  <div>
                    <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">
                      Contact Mobile Phone (For UPI verification)
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                        <Phone className="h-4.5 w-4.5" />
                      </span>
                      <input
                        type="tel"
                        required
                        value={patientFormPhone}
                        onChange={(e) => setPatientFormPhone(e.target.value)}
                        placeholder="e.g. +91 98765 43210"
                        className="w-full bg-[#14181f] border border-white/5 rounded-xl py-2.5 pl-10 pr-4 font-sans text-sm focus:border-cyan-500 focus:bg-[#1a202a] text-slate-100 outline-none transition-all placeholder-slate-500"
                        id="book-patient-phone"
                      />
                    </div>
                  </div>

                  <div className="bg-cyan-500/5 rounded-xl p-3 border border-cyan-500/10 text-xs text-slate-300 space-y-1">
                    <p className="font-extrabold flex items-center gap-1.5 text-cyan-405">
                      <Info className="h-3.5 w-3.5 text-cyan-400" />
                      Mandatory Consultation Booking Deposit
                    </p>
                    <p>
                      Today's hospital OP record entry fee for {activeDepartment?.name || 'clinic'} is <strong className="text-white font-mono font-extrabold text-sm">₹{consultationFee}</strong>. Secure payment via PhonePe/UPI is required before generating and queuing your ticket.
                    </p>
                  </div>

                  {/* Booking Action */}
                  <button
                    type="submit"
                    disabled={isSubmitting || !selectedDeptId}
                    className="w-full bg-cyan-500 hover:bg-cyan-400 disabled:bg-slate-800 text-[#0a0c10] font-sans font-bold py-3 px-4 rounded-xl shadow-lg shadow-cyan-500/10 transition-all text-sm flex items-center justify-center space-x-2 cursor-pointer mt-6"
                    id="btn-book-confirm-queue"
                  >
                    <Sparkles className="h-4.5 w-4.5 text-[#0a0c10]" />
                    <span>Proceed to PhonePay Secure Checkout</span>
                  </button>
                </form>
              </div>
            ) : (
              /* DYNAMIC INTERACTIVE PHONEPE INTEGRATION SCREEN */
              <div className="space-y-4" id="phonepe-payment-panel">
                {/* PhonePe Header Branding */}
                <div className="flex items-center justify-between bg-gradient-to-r from-[#5f259f] to-[#3f196a] p-4.5 rounded-2xl border border-purple-500/10">
                  <div className="flex items-center gap-2">
                    {/* Stylized PhonePe vector-drawn Logo */}
                    <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center font-black text-[#5f259f] font-serif italic text-lg shadow-md select-none shrink-0 border border-purple-300">
                      pe
                    </div>
                    <div>
                      <h4 className="text-xs font-mono font-bold tracking-widest text-[#ffd250] uppercase leading-none">PhonePe</h4>
                      <p className="text-[10px] text-white/85 font-sans">Secure Instant UPI Checkout</p>
                    </div>
                  </div>
                  <div className="bg-white/10 px-2.5 py-0.5 rounded-full text-[9px] font-mono text-white tracking-wider flex items-center gap-1 font-bold">
                    <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping"></span>
                    <span>BHIM UPI SECURE</span>
                  </div>
                </div>

                {/* Show Options, PIN panel, Processing or Success */}
                {paymentState === 'payment_selection' && (
                  <div className="space-y-4">
                    {/* Fee Summary */}
                    <div className="bg-[#14181f] p-4 rounded-xl border border-white/5 flex justify-between items-center">
                      <div>
                        <p className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-bold">Payee Beneficiary</p>
                        <p className="text-xs font-bold text-slate-200 mt-0.5">{hospital.name}</p>
                        <p className="text-[9.5px] text-slate-400">{activeDepartment?.name} Op-Check-in ticket fee</p>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] font-mono text-slate-500 uppercase tracking-wider">Amount Due</p>
                        <p className="text-2xl font-mono font-extrabold text-[#10b981]">₹{consultationFee}.00</p>
                      </div>
                    </div>

                    {/* Method Selector Tabs */}
                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">
                        Select UPI Transfer Method
                      </label>
                      <div className="grid grid-cols-3 gap-1.5">
                        <button
                          type="button"
                          onClick={() => setSelectedMethod('app')}
                          className={`py-2 px-1 text-center rounded-lg border text-[10px] font-bold font-sans transition-all cursor-pointer ${
                            selectedMethod === 'app'
                              ? 'border-purple-500 bg-[#5f259f]/10 text-purple-300'
                              : 'border-white/5 hover:border-white/10 bg-[#14181f]/60 text-slate-400'
                          }`}
                        >
                          PhonePe App
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedMethod('upi_id')}
                          className={`py-2 px-1 text-center rounded-lg border text-[10px] font-bold font-sans transition-all cursor-pointer ${
                            selectedMethod === 'upi_id'
                              ? 'border-purple-500 bg-[#5f259f]/10 text-purple-300'
                              : 'border-white/5 hover:border-white/10 bg-[#14181f]/60 text-slate-400'
                          }`}
                        >
                          UPI ID / VPA
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedMethod('qr')}
                          className={`py-2 px-1 text-center rounded-lg border text-[10px] font-bold font-sans transition-all cursor-pointer ${
                            selectedMethod === 'qr'
                              ? 'border-purple-500 bg-[#5f259f]/10 text-purple-300'
                              : 'border-white/5 hover:border-white/10 bg-[#14181f]/60 text-slate-400'
                          }`}
                        >
                          Scan QR Code
                        </button>
                      </div>
                    </div>

                    {/* Dynamic checkout panels */}
                    {selectedMethod === 'app' && (
                      <div className="bg-[#14181f]/60 p-4 rounded-xl border border-white/5 space-y-3">
                        <div className="flex items-start gap-2.5 text-xs text-slate-300">
                          <Smartphone className="h-5 w-5 text-purple-400 shrink-0 mt-0.5" />
                          <div>
                            <p className="font-bold text-slate-200">Instant PhonePe App Link</p>
                            <p className="text-[11px] text-slate-450 mt-0.5">
                              This request will launch a secure collect intent directly in your PhonePe app on mobile <span className="font-mono text-slate-300">{patientFormPhone}</span>.
                            </p>
                          </div>
                        </div>
                        <div className="bg-[#0f1218] p-2.5 rounded-lg border border-white/5 text-[10.5px] font-mono text-slate-405 flex justify-between">
                          <span>Target VPA ID:</span>
                          <span className="text-purple-400 font-bold">{customUpiId}</span>
                        </div>
                      </div>
                    )}

                    {selectedMethod === 'upi_id' && (
                      <div className="bg-[#14181f]/60 p-4 rounded-xl border border-white/5 space-y-3">
                        <div>
                          <label className="block text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider mb-1">
                            Verify / Custom UPI ID
                          </label>
                          <input
                            type="text"
                            value={customUpiId}
                            onChange={(e) => setCustomUpiId(e.target.value)}
                            placeholder="e.g. mobile@ybl"
                            className="w-full bg-[#0f1218] border border-white/5 rounded-lg py-2 px-3 font-mono text-xs focus:border-purple-500 text-purple-300 outline-none transition-all"
                          />
                        </div>
                        <p className="text-[10px] text-slate-400 leading-relaxed">
                          Enter your valid Virtual Payment Address (VPA) handled by PhonePe (@ybl, @axl, @ibl).
                        </p>
                      </div>
                    )}

                    {selectedMethod === 'qr' && (
                      <div className="bg-[#14181f]/60 p-4 rounded-xl border border-white/5 flex flex-col items-center text-center space-y-3">
                        {/* High fidelity simulated QR Code */}
                        <div className="bg-white p-3 rounded-xl border-4 border-purple-500 relative shadow-inner">
                          <div className="w-24 h-24 grid grid-cols-4 gap-0.5" id="simulated-payment-qr">
                            {/* Standard QR alignment blocks and design */}
                            <div className="bg-slate-900 border-2 border-white"></div>
                            <div className="bg-slate-900"></div>
                            <div className="bg-slate-900"></div>
                            <div className="bg-slate-900 border-2 border-white"></div>
                            
                            <div className="bg-slate-900"></div>
                            <div className="bg-[#5f259f] rounded-xs flex items-center justify-center font-bold text-[7px] text-white">pe</div>
                            <div className="bg-[#5f259f] rounded-xs flex items-center justify-center font-bold text-[7px] text-white">UPI</div>
                            <div className="bg-slate-900"></div>
                            
                            <div className="bg-slate-900"></div>
                            <div className="bg-slate-900"></div>
                            <div className="bg-slate-900"></div>
                            <div className="bg-slate-900"></div>
                            
                            <div className="bg-slate-900 border-2 border-white"></div>
                            <div className="bg-slate-900"></div>
                            <div className="bg-slate-900"></div>
                            <div className="bg-slate-900 border-2 border-white"></div>
                          </div>
                          {/* absolute badge */}
                          <div className="absolute top-1/2 left-1/2 -ml-3 -mt-3 w-6 h-6 rounded-md bg-white border border-purple-500 flex items-center justify-center text-[10px] font-black italic text-[#5f259f]">pe</div>
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-200">Dynamic Scan-Pay Desk Code</p>
                          <p className="text-[10px] text-slate-500">Scan using PhonePe, Google Pay, Paytm or any BHIM scanner.</p>
                        </div>
                      </div>
                    )}

                    {/* Selector Actions */}
                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => setPaymentState('idle')}
                        className="py-2.5 px-4 bg-white/5 hover:bg-white/10 text-slate-300 font-bold rounded-xl text-xs border border-white/5 transition-all cursor-pointer"
                      >
                        Cancel Booking
                      </button>
                      <button
                        type="button"
                        onClick={handleProceedToPin}
                        className="py-2.5 px-4 bg-[#5f259f] hover:bg-[#6f32b1] text-white font-extrabold rounded-xl text-xs transition-all cursor-pointer shadow-lg shadow-purple-900/10 flex items-center justify-center gap-1"
                      >
                        <ShieldCheck className="h-4 w-4" />
                        <span>Pay ₹{consultationFee}.00</span>
                      </button>
                    </div>

                    <div className="text-center text-[9px] text-slate-500 font-mono mt-1 flex justify-center items-center gap-1">
                      <Lock className="h-3 w-3 text-purple-500" />
                      <span>256-Bit SSL Encryption • PhonePe trust verified</span>
                    </div>
                  </div>
                )}

                {/* 4-DIGIT SECURE PIN ENTRY SCREEN */}
                {paymentState === 'pin_entry' && (
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="w-10 h-10 bg-[#5f259f]/10 text-purple-400 border border-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-2">
                        <Lock className="h-5 w-5" />
                      </div>
                      <h4 className="text-xs font-mono font-bold tracking-widest text-[#ffd250] uppercase">Secure UPI PIN Entry</h4>
                      <p className="text-[11px] text-slate-400 mt-1">Paying ₹{consultationFee}.00 to CareQueue Healthcare Services</p>
                    </div>

                    {/* Pin output display circle indicators */}
                    <div className="flex justify-center space-x-4 py-2">
                      {[0, 1, 2, 3].map((idx) => {
                        const isFilled = upiPin.length > idx;
                        return (
                          <div
                            key={idx}
                            className={`w-4.5 h-4.5 rounded-full border-2 transition-all duration-100 ${
                              isFilled
                                ? 'bg-purple-500 border-purple-500 scale-110 shadow-md shadow-purple-500/25'
                                : 'border-slate-700 bg-transparent'
                            }`}
                          />
                        );
                      })}
                    </div>

                    {/* Dynamic virtual Pin pad layout key panel */}
                    <div className="max-w-[280px] mx-auto bg-[#14181f]/40 border border-white/5 p-3 rounded-2xl">
                      <div className="grid grid-cols-3 gap-2">
                        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                          <button
                            key={digit}
                            type="button"
                            onClick={() => handleKeypadPress(digit)}
                            className="bg-[#14181f] hover:bg-[#1f2631] active:scale-95 text-slate-200 py-2.5 rounded-xl font-mono text-sm font-bold border border-white/5 transition-all text-center cursor-pointer"
                          >
                            {digit}
                          </button>
                        ))}
                        <button
                          type="button"
                          onClick={handleKeypadClear}
                          className="bg-transparent hover:bg-white/5 active:scale-95 text-rose-400 py-2.5 rounded-xl text-[10px] font-mono font-bold border border-rose-500/10 transition-all text-center cursor-pointer"
                        >
                          CLR
                        </button>
                        <button
                          type="button"
                          onClick={() => handleKeypadPress('0')}
                          className="bg-[#14181f] hover:bg-[#1f2631] active:scale-95 text-slate-200 py-2.5 rounded-xl font-mono text-sm font-bold border border-white/5 transition-all text-center cursor-pointer"
                        >
                          0
                        </button>
                        <button
                          type="button"
                          onClick={handleKeypadDelete}
                          className="bg-transparent hover:bg-white/5 active:scale-95 text-slate-400 py-2.5 rounded-xl font-mono text-sm transition-all text-center cursor-pointer flex items-center justify-center font-bold"
                          title="Backspace"
                        >
                          ⌫
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <button
                        type="button"
                        onClick={() => setPaymentState('payment_selection')}
                        className="py-2 px-3 bg-white/5 hover:bg-white/10 text-slate-450 border border-white/5 rounded-xl text-xs transition-all font-bold cursor-pointer"
                      >
                        Change Method
                      </button>
                      <button
                        type="button"
                        onClick={handleConfirmPayment}
                        disabled={upiPin.length !== 4}
                        className="py-2 px-3 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-550 disabled:cursor-not-allowed text-white font-extrabold rounded-xl text-xs transition-all cursor-pointer shadow-md shadow-emerald-900/10"
                      >
                        Authorize Secure Pay
                      </button>
                    </div>
                  </div>
                )}

                {/* SECURE BLOCK PROCESSING STATE */}
                {paymentState === 'processing' && (
                  <div className="py-10 text-center space-y-4">
                    <div className="relative w-16 h-16 mx-auto">
                      <div className="w-16 h-16 rounded-full border-4 border-purple-500/20 border-t-purple-500 animate-spin"></div>
                      <ShieldCheck className="h-6 w-6 text-purple-400 absolute top-1/2 left-1/2 -ml-3 -mt-3 animate-pulse" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-250">Processing UPI Transaction</h4>
                      <p className="text-xs text-purple-400 font-mono mt-1 select-none animate-pulse">{paymentProcessStep}</p>
                    </div>
                    <p className="text-[10px] text-slate-500 max-w-xs mx-auto">
                      Please do not close this browser or reload. Contacting central NPCI servers to verify safety parameters.
                    </p>
                  </div>
                )}

                {/* PAYMENT TRANSFERRED SUCCESS STATE */}
                {paymentState === 'success' && (
                  <div className="py-6 text-center space-y-5" id="phonepe-success-panel">
                    <div className="w-16 h-16 bg-emerald-500/10 rounded-full border border-emerald-500/25 flex items-center justify-center mx-auto text-[#10b981] animate-bounce scale-105 shadow-lg shadow-emerald-500/10">
                      <CheckCircle2 className="h-9 w-9 text-emerald-450" />
                    </div>
                    
                    <div className="space-y-1">
                      <span className="text-[10px] font-mono uppercase bg-emerald-500/15 text-emerald-450 px-2.5 py-0.5 rounded-md border border-emerald-500/10 font-bold select-none">
                        Payment Successful
                      </span>
                      <h4 className="text-xl font-serif italic text-white pt-2">₹{consultationFee}.00 Debited</h4>
                      <p className="text-xs text-slate-400">Funds secured by CareQueue Clearing House Desk</p>
                    </div>

                    <div className="bg-[#14181f]/65 border border-white/5 rounded-2xl p-4 text-left text-[11px] font-sans text-slate-400 mx-auto max-w-sm space-y-1.5 leading-normal">
                      <div className="flex justify-between">
                        <span>Debited From:</span>
                        <span className="font-mono text-slate-350 font-bold">{customUpiId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Paid To:</span>
                        <span className="font-sans font-bold text-slate-300">{hospital.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>UPI Ref Transaction ID:</span>
                        <span className="font-mono text-purple-400 font-bold">{txnId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Authorized At:</span>
                        <span className="font-mono text-slate-300">{new Date().toLocaleTimeString()}</span>
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={handleGenerateToken}
                        className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-[#0a0c10] font-sans font-extrabold py-3 px-4 rounded-xl shadow-lg shadow-emerald-500/10 transition-all text-xs flex items-center justify-center space-x-2 cursor-pointer animate-pulse"
                      >
                        <Sparkles className="h-4.5 w-4.5 text-[#0a0c10]" />
                        <span>Issue CareQueue Digital Token Receipt</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      ) : (
        /* GORGEOUS booked ticket screen */
        <div className="bg-[#0f1218] rounded-3xl border border-white/5 shadow-2xl p-6 sm:p-8 max-w-lg mx-auto text-center" id="booked-receipt-container">
          <div className="w-14 h-14 bg-cyan-500/10 rounded-full border border-cyan-500/20 flex items-center justify-center mx-auto text-cyan-400 mb-4 animate-bounce">
            <CheckCircle2 className="h-7 w-7" />
          </div>

          <h3 className="text-2xl font-serif italic text-white font-medium">
            {t.booking_confirmed}
          </h3>
          <p className="text-slate-400 text-xs sm:text-sm font-sans mt-1">
            {t.booking_under_text}
          </p>

          {/* Ticket Physical Mockup */}
          <div className="my-6 bg-[#14181f] rounded-2xl border border-white/5 p-6 relative overflow-hidden text-left shadow-md">
            {/* Left and right notch cutouts for ticket aesthetic */}
            <div className="absolute -left-3 top-1/2 -mt-3 w-6 h-6 bg-[#0a0c10] rounded-full border-r border-white/5"></div>
            <div className="absolute -right-3 top-1/2 -mt-3 w-6 h-6 bg-[#0a0c10] rounded-full border-l border-white/5"></div>
            
            {/* Ticket Header */}
            <div className="pb-4 border-b border-dashed border-white/10 text-center">
              <span className="text-[10px] font-mono tracking-wider font-extrabold text-[#94a3b8] uppercase">
                {t.ticket_digital_receipt}
              </span>
              <div className="text-4xl font-mono font-extrabold text-cyan-400 tracking-tight mt-1.5" id="receipt-token-number">
                {bookedReceipt.tokenNumber}
              </div>
              <p className="text-sm font-sans font-bold text-slate-200 mt-1">{bookedReceipt.patientName}</p>
            </div>

            {/* Ticket Details */}
            <div className="pt-4 space-y-2.5 text-xs text-slate-400 font-sans">
              <div className="flex justify-between">
                <span>{language === 'en' ? 'Facility:' : language === 'hi' ? 'अस्पताल:' : language === 'te' ? 'ఆసుపత్రి:' : language === 'ta' ? 'மருத்துவமனை:' : 'ആശുപത്രി:'}</span>
                <span className="font-bold text-slate-200 text-right max-w-[180px] truncate">{bookedReceipt.hospitalName}</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'en' ? 'Department:' : language === 'hi' ? 'विभाग:' : language === 'te' ? 'విభాగం:' : language === 'ta' ? 'துறை:' : 'വിഭാഗം:'}</span>
                <span className="font-bold text-slate-200">{bookedReceipt.departmentName}</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'en' ? 'Clinician:' : language === 'hi' ? 'चिकित्सक:' : language === 'te' ? 'వైద్యులు:' : language === 'ta' ? 'மருத்துவர்:' : 'ഡോക്ടർ:'}</span>
                <span className="font-bold text-slate-200">
                  {hospital.departments.find(d => d.id === bookedReceipt.departmentId)?.doctorName} • {hospital.departments.find(d => d.id === bookedReceipt.departmentId)?.roomNumber}
                </span>
              </div>
              <div className="flex justify-between">
                <span>{t.position_in_queue}:</span>
                <span className="font-bold text-cyan-400 font-mono">
                  #{calculatePositionAndWait(bookedReceipt.id).position + 1} ({calculatePositionAndWait(bookedReceipt.id).position} {language === 'en' ? 'ahead' : language === 'hi' ? 'आगे' : language === 'te' ? 'ముందున్నారు' : language === 'ta' ? 'முன்னால்' : 'മുൻപിൽ'})
                </span>
              </div>
              <div className="flex justify-between pt-2 border-t border-white/5">
                <span>{t.reg_time}:</span>
                <span className="font-mono text-slate-300 font-bold">
                  {new Date(bookedReceipt.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
              <div className="flex justify-between text-base font-bold text-slate-200 pt-2 border-t border-dashed border-white/10">
                <span>{t.est_waiting}:</span>
                <span className="font-mono text-cyan-400">
                  ~ {calculatePositionAndWait(bookedReceipt.id).estimatedWaitMins} {t.mins}
                </span>
              </div>
            </div>
          </div>

          {/* Action Footer */}
          <div className="space-y-2">
            <button
              onClick={() => onTokenBooked(bookedReceipt)}
              className="w-full bg-cyan-500 hover:bg-cyan-400 text-[#0a0c10] font-sans font-bold py-2.5 px-4 rounded-xl shadow-md transition-all text-sm flex items-center justify-center space-x-2 cursor-pointer"
              id="receipt-btn-tracker"
            >
              <span>{t.track_live_btn}</span>
              <ChevronRight className="h-4 w-4" />
            </button>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => window.print()}
                className="bg-white/5 hover:bg-white/10 border border-white/5 text-slate-200 font-sans font-bold py-2.5 px-3 rounded-xl transition-all text-xs flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <span>{language === 'en' ? 'Print Ticket' : language === 'hi' ? 'प्रिंट' : language === 'te' ? 'ప్రింట్' : language === 'ta' ? 'அச்சிடு' : 'അച്ചടിക്കുക'}</span>
              </button>
              <button
                onClick={handleDownloadTicketFile}
                className="bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/20 text-cyan-400 font-sans font-bold py-2.5 px-3 rounded-xl transition-all text-xs flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                <span>{language === 'en' ? 'Download TXT' : language === 'hi' ? 'डाउनलोड (.TXT)' : language === 'te' ? 'డౌన్‌లోడ్ (.TXT)' : language === 'ta' ? 'பதிவிறக்கம் (.TXT)' : 'ഡൗൺലോഡ് (.TXT)'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
