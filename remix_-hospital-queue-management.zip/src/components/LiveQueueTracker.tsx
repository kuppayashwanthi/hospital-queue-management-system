import React, { useState, useEffect } from 'react';
import { Clock, MapPin, CheckCircle2, AlertTriangle, Volume2, UserCheck, RefreshCw, Calendar, ArrowLeft, Play, LayoutGrid, Activity } from 'lucide-react';
import { Token } from '../types';
import { calculatePositionAndWait, loadQueueState, updateTokenStatus } from '../lib/queueEngine';
import { INITIAL_HOSPITALS } from '../data';
import { LanguageType, translations } from '../lib/translations';

interface LiveQueueTrackerProps {
  token: Token;
  onBackToHospitals: () => void;
  onRefresh: () => void;
  language: LanguageType;
}

export default function LiveQueueTracker({
  token: initialToken,
  onBackToHospitals,
  onRefresh,
  language
}: LiveQueueTrackerProps) {
  const [tokenState, setTokenState] = useState<Token>(initialToken);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [lastAnnouncedIndex, setLastAnnouncedIndex] = useState('');

  const t = translations[language];

  // Reload/Update state from localStorage periodically
  useEffect(() => {
    const fetchLatest = () => {
      const state = loadQueueState();
      const current = state.tokens.find(t => t.id === tokenState.id);
      if (current) {
        setTokenState(current);
      }
    };

    fetchLatest();
    // Poll every 2 seconds for ultra-responsive live sync
    const interval = setInterval(fetchLatest, 2000);
    return () => clearInterval(interval);
  }, [tokenState.id]);

  const { position, estimatedWaitMins } = calculatePositionAndWait(tokenState.id);

  // Get active doctor of this department
  const hospital = INITIAL_HOSPITALS.find(h => h.id === tokenState.hospitalId);
  const department = hospital?.departments.find(d => d.id === tokenState.departmentId);
  const doctorName = department?.doctorName || 'Assigned Clinician';
  const roomNumber = department?.roomNumber || 'Room A';

  // Text-To-Speech Queue Caller Announcement Simulation
  const handleAnnouncementSpeech = () => {
    if ('speechSynthesis' in window) {
      setIsSpeaking(true);
      window.speechSynthesis.cancel(); // stop current

      let text = '';
      if (language === 'hi') {
        text = tokenState.status === 'calling'
          ? `कृपया ध्यान दें। टोकन नंबर, ${tokenState.tokenNumber.split('').join(' ')}, ${tokenState.patientName}, कृपया ${tokenState.departmentName} विभाग में डॉक्टर, ${doctorName} के पास कमरा नंबर ${roomNumber} पर जाएँ।`
          : `टोकन ${tokenState.tokenNumber.split('').join(' ')} सक्रिय है। आपके आगे ${position} मरीज हैं, और प्रतीक्षा समय लगभग ${estimatedWaitMins} मिनट है।`;
      } else if (language === 'te') {
        text = tokenState.status === 'calling'
          ? `దయచేసి వినండి. టోకెన్ సంఖ్య, ${tokenState.tokenNumber.split('').join(' ')}, ${tokenState.patientName}, దయచేసి రూమ్ ${roomNumber} లోని డాక్టర్, ${doctorName} ని సంప్రదించండి.`
          : `క్యూలో మీ స్థానం ట్రాక్ చేయబడుతోంది. మీకంటే ముందు ${position} మంది రోగులు ఉన్నారు. నిరీక్షణ సమయం ${estimatedWaitMins} నిమిషాలు.`;
      } else if (language === 'ta') {
        text = tokenState.status === 'calling'
          ? `தயவுசெய்து கவனிக்கவும். டோக்கன் எண், ${tokenState.tokenNumber.split('').join(' ')}, ${tokenState.patientName}, தயவுசெய்து அறை எண், ${roomNumber} -ல் உள்ள மருத்துவர் ${doctorName} -ஐப் பார்க்கவும்.`
          : `உங்களுக்கு முன்னால் ${position} நோயாளிகள் உள்ளனர். காத்திருப்பு நேரம் ${estimatedWaitMins} நிமிடங்கள்.`;
      } else if (language === 'ml') {
        text = tokenState.status === 'calling'
          ? `ദയവായി ശ്രദ്ധിക്കുക. ടോക്കൺ നമ്പർ, ${tokenState.tokenNumber.split('').join(' ')}, ${tokenState.patientName}, ദയവായി റൂം നമ്പർ, ${roomNumber}-ലേക്ക് പോവുക.`
          : `നിങ്ങൾക്ക് മുൻപിൽ ${position} രോഗികളുണ്ട്. കാത്തിരിപ്പ് സമയം ${estimatedWaitMins} മിനിറ്റാണ്.`;
      } else {
        // Fallback to English
        text = tokenState.status === 'calling'
          ? `Attention please. Token, ${tokenState.tokenNumber.split('').join(' ')}, ${tokenState.patientName}, please proceed to ${roomNumber} for ${tokenState.departmentName} under ${doctorName}.`
          : `Token ${tokenState.tokenNumber.split('').join(' ')} is currently active in the ${tokenState.departmentName} clinic queue. There are ${position} patients ahead, with an estimated wait of ${estimatedWaitMins} minutes.`;
      }

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      
      // Select appropriate local voice if available
      const voices = window.speechSynthesis.getVoices();
      const selectedVoice = voices.find(voice => {
        const name = voice.name.toLowerCase();
        const langCode = voice.lang.toLowerCase();
        if (language === 'hi' && (langCode.startsWith('hi') || name.includes('india'))) return true;
        if (language === 'te' && (langCode.startsWith('te') || name.includes('india'))) return true;
        if (language === 'ta' && (langCode.startsWith('ta') || name.includes('india'))) return true;
        if (language === 'ml' && (langCode.startsWith('ml') || name.includes('india'))) return true;
        return name.includes('google') || name.includes('female');
      }) || voices[0];

      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
      utterance.rate = 0.95; // moderate clear speed
      utterance.pitch = 1.05; // slightly friendly receptionist pitch

      window.speechSynthesis.speak(utterance);
    } else {
      alert('Text-to-speech audio announcements are not supported on your local browser settings/device.');
    }
  };

  // Helper: format ISO date to readable string
  const formatTime = (isoString?: string) => {
    if (!isoString) return '';
    return new Date(isoString).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  // Timeline events based on status
  const getTimelineEvents = () => {
    const events = [
      {
        title: language === 'en' ? 'Token Registered' : language === 'hi' ? 'टोकन पंजीकृत' : language === 'te' ? 'టోకెన్ నమోదైంది' : language === 'ta' ? 'டோக்கன் பதிவு செய்யப்பட்டது' : 'ടോക്കൺ രജിസ്റ്റർ ചെയ്തു',
        desc: language === 'en' ? 'Digital check-in booked successfully.' : language === 'hi' ? 'डिजिटल चेक-इन सफलतापूर्वक बुक किया गया।' : language === 'te' ? 'డిజిటൽ చెక్-ఇన్ విజయవంతంగా పూర్తయింది.' : language === 'ta' ? 'டிஜிட்டல் சரிபார்ப்பு வெற்றிகரமாக செய்யப்பட்டது.' : 'ഡിജിറ്റൽ ചെക്ക് ഇൻ വിജയകരമായി പൂർത്തിയായി.',
        time: formatTime(tokenState.createdAt),
        completed: true
      }
    ];

    if (tokenState.status === 'calling' || tokenState.status === 'completed') {
      events.push({
        title: language === 'en' ? 'Called to Cabin' : language === 'hi' ? 'कैबिन में बुलाया गया' : language === 'te' ? 'క్యాబిన్‌కు పిలిచారు' : language === 'ta' ? 'அறைக்கு அழைக்கப்பட்டது' : 'ക്യാബിനിലേക്ക് വിളിച്ചു',
        desc: language === 'en' ? `Summoned to ${roomNumber} under ${doctorName}.` : language === 'hi' ? `कमरा नंबर ${roomNumber} पर डॉक्टर ${doctorName} के पास बुलाया गया।` : language === 'te' ? `రూమ్ ${roomNumber} లో డాక్టర్ ${doctorName} వద్దకు పిలుపు.` : language === 'ta' ? `அறை எண் ${roomNumber} -ல் டாக்டர் ${doctorName} பார்க்க அழைக்கப்படுகிறீர்கள்.` : `റൂം ${roomNumber}-ലേക്ക് ഡോക്ടർ ${doctorName}-ൻ്റെ അടുക്കലേക്ക് വിളിച്ചു.`,
        time: formatTime(tokenState.calledAt || new Date().toISOString()),
        completed: true
      });
    } else if (tokenState.status === 'waiting') {
      events.push({
        title: `${language === 'en' ? 'Waiting Queue' : language === 'hi' ? 'प्रतीक्षा सूची' : language === 'te' ? 'నిరీక్షణ జాబితా' : language === 'ta' ? 'காத்திருப்பு வரிசை' : 'കാത്തിരിപ്പ് പട്ടിക'} (#${position + 1} ${language === 'en' ? 'In Line' : language === 'hi' ? 'लाइन में' : language === 'te' ? 'లైన్లో ఉన్నారు' : language === 'ta' ? 'வரிசையில்' : 'ക്യൂവിൽ'})`,
        desc: `${position} ${language === 'en' ? 'matching patients remain ahead.' : language === 'hi' ? 'मरीज आपके आगे प्रतीक्षा में हैं।' : language === 'te' ? 'మంది రోగులు మీకంటే ముందున్నారు.' : language === 'ta' ? 'நோயாளிகள் உங்களுக்கு முன்னால் உள்ளனர்.' : 'രോഗികൾ നിങ്ങൾക്ക് മുൻപിലുണ്ട്.'}`,
        time: language === 'en' ? 'Live Tracker Active' : language === 'hi' ? 'सक्रिय ट्रैकर' : language === 'te' ? 'ప్రత్యక్ష ట్రాకర్' : language === 'ta' ? 'நேரடி கண்காணிப்பு' : 'തത്സമയ ട്രാക്കിങ്',
        completed: false
      });
    }

    if (tokenState.status === 'completed') {
      events.push({
        title: language === 'en' ? 'Check-In Finished' : language === 'hi' ? 'चेक-इन समाप्त' : language === 'te' ? 'వైద్య परीक्षा పూర్తయింది' : language === 'ta' ? 'முடிந்தது' : 'സന്ദർശനം പൂർത്തിയായി',
        desc: language === 'en' ? 'Consultation concluded successfully.' : language === 'hi' ? 'परामर्श सफलतापूर्वक संपन्न हुआ।' : language === 'te' ? 'కన్సల్టేషన్ విజయవంతంగా ముగిసింది.' : language === 'ta' ? 'ஆலோசனை வெற்றிகரமாக முடிந்தது.' : 'പരിശോധന വിജയകരമായി പൂർത്തിയായി.',
        time: formatTime(tokenState.completedAt || new Date().toISOString()),
        completed: true
      });
    }

    return events;
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6" id="live-tracker-page">
      {/* Return Navigation */}
      <button
        onClick={onBackToHospitals}
        className="inline-flex items-center gap-2 px-4 py-2 bg-[#14181f]/80 text-slate-300 hover:text-white text-xs sm:text-sm font-bold border border-white/10 hover:border-cyan-500/30 rounded-xl transition-all cursor-pointer shadow-md group"
        id="btn-tracker-back"
      >
        <ArrowLeft className="h-4 w-4 text-cyan-400 group-hover:-translate-x-1 transition-transform" />
        <span>{t.return_to_facilities}</span>
      </button>

      {/* Main Status Display Panel based on token.status */}
      <div className="bg-[#0f1218] rounded-3xl border border-white/5 shadow-2xl overflow-hidden">
        {/* Status indicator bar */}
        <div className={`p-4 text-center text-xs font-mono font-bold tracking-widest uppercase border-b ${
          tokenState.status === 'calling' ? 'bg-amber-500/15 text-amber-400 border-amber-500/20 animate-pulse' :
          tokenState.status === 'completed' ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20' :
          tokenState.status === 'skipped' ? 'bg-rose-500/15 text-rose-400 border-rose-500/20' :
          'bg-cyan-500/15 text-cyan-400 border-cyan-500/20'
        }`}>
          {tokenState.status === 'calling' && `📢 ${t.turn_arrived}`}
          {tokenState.status === 'completed' && `✅ ${t.check_complete}`}
          {tokenState.status === 'skipped' && `❌ ${t.token_skipped}`}
          {tokenState.status === 'waiting' && `⏳ ${language === 'en' ? 'Active Waiting Status' : language === 'hi' ? 'सक्रिय प्रतीक्षा प्रणाली' : language === 'te' ? 'క్రియాశీల నిరీక్షణ స్థితి' : language === 'ta' ? 'காத்திருப்பு நிலை' : 'തത്സമയ ക്യൂ നില'}`}
        </div>

        <div className="p-6 sm:p-8">
          <div className="text-center space-y-4">
            <span className="text-xs uppercase tracking-wider font-bold font-mono text-slate-300 bg-slate-900 border border-white/10 px-3 py-1.5 rounded-lg inline-block">
              {tokenState.hospitalName} • {tokenState.departmentName}
            </span>

            {/* BIG GLOWING TOKEN DISPLAY */}
            <div className={`w-40 h-40 mx-auto rounded-full border-4 flex flex-col justify-center items-center transition-all ${
              tokenState.status === 'calling' ? 'bg-amber-500/5 border-amber-500/50 shadow-lg shadow-amber-500/15 scale-105' :
              tokenState.status === 'completed' ? 'bg-emerald-500/5 border-emerald-500/40' :
              tokenState.status === 'skipped' ? 'bg-rose-500/5 border-rose-500/40' :
              'bg-cyan-500/5 border-cyan-500/45 shadow-lg shadow-cyan-500/10'
            }`}>
              <p className="text-[10px] font-mono font-bold uppercase text-slate-500 tracking-wider font-semibold">{t.token_code}</p>
              <h2 className="text-3xl font-mono font-extrabold text-white tracking-tight mt-1">{tokenState.tokenNumber}</h2>
              <span className={`text-[10.5px] font-bold px-2 py-0.5 rounded-md mt-1 font-sans border ${
                tokenState.status === 'calling' ? 'bg-amber-500/15 text-amber-400 border-amber-500/10' :
                tokenState.status === 'completed' ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/10' :
                tokenState.status === 'skipped' ? 'bg-rose-500/15 text-rose-400 border-rose-500/10' :
                'bg-cyan-500/15 text-cyan-400 border-cyan-500/10'
              }`}>
                {tokenState.status.toUpperCase()}
              </span>
            </div>

            {/* STATUS MESSAGES INTERRUPTS */}
            {tokenState.status === 'waiting' && (
              <div className="space-y-4 pt-2">
                <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
                  <div className="p-4 bg-[#14181f] rounded-2xl border border-white/5">
                    <p className="text-[10px] uppercase font-mono font-bold tracking-wider text-slate-500">{t.position_ahead}</p>
                    <p className="text-2xl font-sans font-extrabold text-slate-200 mt-1">
                      {position} <span className="text-xs font-semibold text-slate-550">{t.patients}</span>
                    </p>
                  </div>
                  <div className="p-4 bg-[#14181f] rounded-2xl border border-white/5">
                    <p className="text-[10px] uppercase font-mono font-bold tracking-wider text-slate-500">{t.est_wait_time}</p>
                    <p className="text-2xl font-sans font-extrabold text-cyan-450 mt-1 font-mono">
                      ~{estimatedWaitMins} <span className="text-xs font-semibold text-slate-550 font-sans">{t.mins}</span>
                    </p>
                  </div>
                </div>

                <div className="bg-[#14181f]/60 p-4 rounded-xl text-xs sm:text-sm text-slate-400 font-sans max-w-md mx-auto text-center border border-white/5">
                  <span className="font-bold text-slate-200">
                    {language === 'en' ? 'Currently serving:' : language === 'hi' ? 'वर्तमान सेवा:' : language === 'te' ? 'ప్రస్తుత సేవ:' : language === 'ta' ? 'தற்போது பார்க்கப்படும் நோயாளி:' : 'നിലവിൽ പരിശോധിക്കുന്നത്:'}
                  </span>
                  {language === 'en' ? ' and tracking this queue. Please stay nearby. When your token is called, an announcement will broadcast.' : language === 'hi' ? ' और इस कतार की निगरानी हो रही है। कृपया निकट रहें। आपकी बारी पर उद्घोषणा होगी।' : language === 'te' ? ' మరియు ఈ క్యూను ట్రాక్ చేస్తున్నాము. దయచేസി దగ్గరలోనే ఉండండి. మీ టోకెన్ పిలిచినప్పుడు అనౌన్స్మెంట్ వినబడుతుంది.' : language === 'ta' ? ' மற்றும் இந்த வரிசை கண்காணிக்கப்படுகிறது. அருகிலேயே இருக்கவும். உங்கள் டோக்கன் அழைக்கப்படும் போது அறிவிப்பு வெளியாகும்.' : ' കൂടാതെ ഈ ക്യൂ നിരീക്ഷിക്കുന്നു. ദയവായി അടുത്തു തന്നെ തുടരുക. നിങ്ങളുടെ ടോക്കൺ വിളിക്കുമ്പോൾ അറിയിപ്പ് ലഭിക്കുന്നതാണ്.'}
                </div>
              </div>
            )}

            {tokenState.status === 'calling' && (
              <div className="space-y-4 pt-2 max-w-md mx-auto">
                <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl text-slate-200 shadow-sm text-center">
                  <h4 className="font-sans font-extrabold text-amber-400 text-lg">{t.turn_arrived}</h4>
                  <p className="text-xs leading-relaxed text-slate-300 font-medium mt-1">
                    {language === 'en' ? 'Please proceed to' : language === 'hi' ? 'कृपया कमरा नंबर' : language === 'te' ? 'దయచేసి రూమ్' : language === 'ta' ? 'தயவுசெய்து அறை எண்' : 'ദയവായി റൂം നമ്പർ'} <span className="font-bold text-amber-300">{roomNumber}</span>. <span className="font-bold text-amber-300">{doctorName}</span> {language === 'en' ? 'is ready to see you.' : language === 'hi' ? 'पर जाएँ। वह आपकी प्रतीक्षा कर रहे हैं।' : language === 'te' ? 'కి వెళ్ళండి. వైద్యులు సిద్ధంగా ఉన్నారు.' : language === 'ta' ? 'செல்லவும். மருத்துவர் தயாராக உள்ளார்.' : '-ലേക്ക് പോവുക. ഡോക്ടർ തയ്യാറാണ്.'}
                  </p>
                </div>

                {/* Simulated buzzer call */}
                <button
                  onClick={handleAnnouncementSpeech}
                  disabled={isSpeaking}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-[#0a0c10] rounded-xl shadow-md font-extrabold text-xs transition-all cursor-pointer animate-bounce"
                  id="btn-voice-caller-simulator"
                >
                  <Volume2 className={`h-4 w-4 text-[#0a0c10] ${isSpeaking ? 'animate-pulse' : ''}`} />
                  <span>{isSpeaking ? (language === 'en' ? 'Announcing...' : language === 'hi' ? 'घोषणा हो रही है...' : language === 'te' ? 'ప్రకటిస్తోంది...' : language === 'ta' ? 'அறிவிக்கப்படுகிறது...' : 'അനൗൺസ് ചെയ്യുന്നു...') : (language === 'en' ? 'Hear Room Call Audio Announcement' : language === 'hi' ? 'ऑडियो घोषणा सुनें' : language === 'te' ? 'ఆడియో అనౌన్స్మెంట్ వినండి' : language === 'ta' ? 'ஒலி அறிவிப்பைக் கேளுங்கள்' : 'അനൗൺസ്മെന്റ് കേൾക്കുക')}</span>
                </button>
              </div>
            )}

            {tokenState.status === 'completed' && (
              <div className="p-5 bg-emerald-500/10 rounded-2xl max-w-sm mx-auto text-center border border-emerald-500/20 text-slate-300">
                <h4 className="font-sans font-extrabold text-emerald-400 text-base">{t.check_complete}</h4>
                <p className="text-xs text-slate-405 mt-1">
                  {language === 'en' ? 'Thank you for using CareQueue. Your visit to ' : language === 'hi' ? 'केयरकतार का उपयोग करने के लिए धन्यवाद। आपका परामर्श ' : language === 'te' ? 'కేర్ క్యూ ఉపయోగించినందుకు ధన్యവാദాలు. మీ డాక్టర్ ' : language === 'ta' ? 'கேர்கியூ பயன்படுத்தியதற்கு நன்றி. மருத்துவர் ' : 'കെയർക്യൂ ഉപയോഗിച്ചതിന് നന്ദി. ഡോക്ടർ '} <span className="text-slate-200 font-bold">{doctorName}</span> {language === 'en' ? ' at the department clinic is wrapped up.' : language === 'hi' ? ' के साथ पूर्ण हुआ।' : language === 'te' ? ' తో వైద్య పరీక్ష ముగిసింది.' : language === 'ta' ? ' உடனாக ஆலோசனை நிறைவடைந்தது.' : '-തുമായുള്ള കൂടിക്കാഴ്‌ച വിജയകരമായി പൂർത്തിയായി.'}
                </p>
              </div>
            )}

            {tokenState.status === 'skipped' && (
              <div className="p-5 bg-rose-500/10 rounded-2xl max-w-sm mx-auto text-center border border-rose-500/20 text-slate-300">
                <h4 className="font-sans font-extrabold text-rose-400 text-base">{t.token_skipped}</h4>
                <p className="text-xs text-slate-405 mt-1">
                  {language === 'en' ? 'This queue appointment has been closed or was skipped. Please register a brand new token or consult the front hospital triage desk immediately.' : language === 'hi' ? 'इस टोकन को कतार से हटा दिया गया है या छोड़ दिया गया है। कृपया नया टोकन प्राप्त करें या पूछताछ केंद्र से संपर्क करें।' : language === 'te' ? 'ఈ టోకెన్ అపాయింట్‌మెంట్ రద్దు చేయబడింది లేదా దాటవేయబడింది. దయచేസി కొత్త టోకెన్ తీసుకోండి లేదా సహాయ కేంద్రాన్ని సంప్రదించండి.' : language === 'ta' ? 'இந்த டோக்கன் ரத்து செய்யப்பட்டுள்ளது அல்லது தவிர்க்கப்பட்டது. தயవుசெய்து புதிய டோக்கன் பதிவு செய்யவும் அல்லது தகவல் மையத்தை அணுகவும்.' : 'ഈ ടോക്കൺ പരിശോധന ഉപേക്ഷിക്കുകയോ റദ്ദാക്കുകയോ ചെയ്തിരിക്കുന്നു. ദയവായി പുതിയ ടോക്കൺ എടുക്കുകയോ ഡെസ്കിൽ ബന്ധപ്പെടുകയോ ചെയ്യുക.'}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Patient Timeline Flow History */}
      <div className="bg-[#0f1218] rounded-3xl border border-white/5 p-6 sm:p-8 shadow-2xl">
        <h4 className="font-serif italic text-white text-base mb-5 flex items-center gap-2">
          <Activity className="h-4.5 w-4.5 text-cyan-400" />
          {language === 'en' ? 'Queue Audit Timeline Logs' : language === 'hi' ? 'कतार ऑडिट इतिहास' : language === 'te' ? 'క్యూ ఆడిట్ టైమ్‌లైన్ రికార్డులు' : language === 'ta' ? 'வரிசை வரலாற்றுப் பதிவு' : 'ക്യൂ ഓഡിറ്റ് പുരോഗതി'}
        </h4>
        
        <div className="space-y-6 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-white/5" id="audit-timeline">
          {getTimelineEvents().map((event, index) => (
            <div key={index} className="flex gap-4 relative">
              {/* Bullet circle */}
              <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 z-10 ${
                event.completed 
                  ? 'bg-cyan-500/10 border border-cyan-500/30 text-cyan-400' 
                  : 'bg-slate-900 border border-white/10 text-slate-500'
              }`}>
                <CheckCircle2 className="h-3.5 w-3.5" />
              </div>
              
              <div>
                <p className="font-sans font-extrabold text-sm text-slate-200 leading-tight">
                  {event.title}
                </p>
                <p className="font-sans text-xs text-slate-405 mt-0.5">
                  {event.desc}
                </p>
                <p className="font-mono text-[10px] bg-[#14181f] text-slate-400 font-bold px-2 py-0.5 rounded-sm border border-white/5 inline-block mt-1">
                  {event.time}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
