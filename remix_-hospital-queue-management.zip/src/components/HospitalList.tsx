import React, { useState } from 'react';
import { Search, Star, MapPin, Clock, Phone, ChevronRight, Sparkles, Building } from 'lucide-react';
import { Hospital } from '../types';
import { INITIAL_HOSPITALS } from '../data';
import { loadQueueState } from '../lib/queueEngine';
import { LanguageType, translations } from '../lib/translations';

interface HospitalListProps {
  onSelectHospital: (hospital: Hospital) => void;
  onBookTokenClick: (hospital: Hospital, deptId?: string) => void;
  language: LanguageType;
}

export default function HospitalList({ onSelectHospital, onBookTokenClick, language }: HospitalListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const state = loadQueueState();
  const t = translations[language];

  // Helper: Count waiting patients in a hospital
  const getHospitalWaitingCount = (hospId: string) => {
    return state.tokens.filter(t => t.hospitalId === hospId && (t.status === 'waiting' || t.status === 'calling')).length;
  };

  // Helper: Calculate average wait time for the hospital
  const getAverageWaitTime = (hospital: Hospital) => {
    const totalPatients = getHospitalWaitingCount(hospital.id);
    if (totalPatients === 0) {
      return language === 'en' ? 'No wait' : language === 'hi' ? 'कोई प्रतीक्षा नहीं' : language === 'te' ? 'నిరీక్షణ లేదు' : language === 'ta' ? 'காத்திருப்பு இல்லை' : 'കാത്തിരിപ്പില്ല';
    }
    
    // Average base time across all departments
    const avgBase = hospital.departments.reduce((sum, d) => sum + d.baseTimeMins, 0) / hospital.departments.length;
    const estimated = Math.round(totalPatients * (avgBase / hospital.departments.length));
    return `${estimated || 5}–${estimated + 10} ${t.mins}`;
  };

  // Filter hospitals
  const categories = ['All', 'Primary Care', 'Pediatrics', 'Heart Health', 'Emergency'];
  
  const filteredHospitals = INITIAL_HOSPITALS.filter(hosp => {
    const matchesSearch = hosp.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          hosp.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          hosp.departments.some(d => d.name.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'All' || 
                            hosp.departments.some(d => d.category === selectedCategory || d.name.includes(selectedCategory));

    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-6" id="hospital-list-page">
      {/* Search Header Banner */}
      <div className="bg-[#0f1218] border border-white/5 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-2xl mb-2">
        <div className="absolute right-0 bottom-0 top-0 opacity-5 pointer-events-none w-1/2 flex items-center justify-center">
          <Building className="h-64 w-64" />
        </div>
        
        <div className="relative z-10 max-w-xl">
          <span className="inline-flex items-center space-x-1.5 bg-cyan-500/10 text-cyan-400 text-xs px-2.5 py-1 rounded-full border border-cyan-500/10 font-bold tracking-wide uppercase mb-3 animate-pulse">
            <Sparkles className="h-3 w-3 text-cyan-400" />
            <span>{language === 'en' ? 'Healthcare Directory' : language === 'hi' ? 'स्वास्थ्य सेवा निर्देशिका' : language === 'te' ? 'వైద్య ఆరోగ్య సమాచారం' : language === 'ta' ? 'சுகாதார அடைவு' : 'ഹെൽത്ത്കെയർ ഡയറക്ടറി'}</span>
          </span>
          <h2 className="text-2xl sm:text-3xl font-serif italic font-medium tracking-tight text-white">
            {t.select_facility}
          </h2>
          <p className="mt-1.5 text-sm text-slate-400 font-sans opacity-90">
            {t.booking_subtitle}
          </p>

          <div className="mt-5 relative">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
              <Search className="h-4 w-4 text-cyan-400" />
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.search_placeholder}
              className="w-full bg-[#14181f] text-slate-100 placeholder-slate-500 border border-white/5 rounded-xl py-3 pl-10 pr-4 font-sans text-sm focus:border-cyan-500 outline-none transition-all shadow-md"
              id="hospital-search-input"
            />
          </div>
        </div>
      </div>

      {/* Categories chips filter */}
      <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-none" id="categories-tabs">
        {categories.map((cat) => {
          const catName = cat === 'All' ? (language === 'en' ? 'All' : language === 'hi' ? 'सभी' : language === 'te' ? 'అన్నీ' : language === 'ta' ? 'அனைத்தும்' : 'എല്ലാം') : cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`whitespace-nowrap px-4 py-2 rounded-xl text-xs font-sans font-bold border transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-cyan-500 text-[#0a0c10] border-cyan-500 shadow-lg shadow-cyan-500/15'
                  : 'bg-white/5 hover:bg-white/10 text-slate-400 border-white/5'
              }`}
            >
              {catName}
            </button>
          );
        })}
      </div>

      {/* Hospitals Grid */}
      {filteredHospitals.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5" id="hospitals-grid">
          {filteredHospitals.map((hospital) => {
            const waitingCount = getHospitalWaitingCount(hospital.id);
            const avgWait = getAverageWaitTime(hospital);

            return (
              <div
                key={hospital.id}
                className="bg-[#0f1218] rounded-2xl border border-white/5 shadow-xl hover:border-cyan-500/30 hover:shadow-cyan-500/5 transition-all duration-300 flex flex-col justify-between overflow-hidden group"
                id={`hospital-card-${hospital.id}`}
              >
                <div>
                  {/* Photo / Thumbnail */}
                  <div className="h-40 w-full overflow-hidden relative bg-slate-900 border-b border-white/5">
                    <img
                      src={hospital.image}
                      alt={hospital.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80 group-hover:opacity-100"
                    />
                    <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-md text-xs font-bold px-2.5 py-1 rounded-lg text-slate-200 border border-white/10 shadow-sm flex items-center gap-1">
                      <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-500" />
                      <span>{hospital.rating.toFixed(1)}</span>
                    </div>

                    {/* Department Badges Overlay */}
                    <div className="absolute bottom-3 left-3 flex flex-wrap gap-1">
                      {hospital.departments.slice(0, 2).map((dept) => (
                        <span key={dept.id} className="text-[9px] uppercase font-bold font-mono bg-slate-900/95 text-cyan-400 border border-white/10 px-2 py-0.5 rounded-md backdrop-blur-sm">
                          {dept.name.split(' ')[0]}
                        </span>
                      ))}
                      {hospital.departments.length > 2 && (
                        <span className="text-[9px] font-bold font-mono bg-slate-900/95 text-slate-300 border border-white/10 px-2 py-0.5 rounded-md backdrop-blur-sm">
                          +{hospital.departments.length - 2} {language === 'en' ? 'More' : language === 'hi' ? 'अधिक' : language === 'te' ? 'మరిన్ని' : language === 'ta' ? 'கூடுதல்' : 'കൂടുതൽ'}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Info Details */}
                  <div className="p-5">
                    <h3 className="font-serif italic font-medium text-lg text-white group-hover:text-cyan-400 transition-colors">
                      {hospital.name}
                    </h3>

                    <div className="mt-2.5 space-y-2 text-xs sm:text-sm text-slate-400">
                      <p className="flex items-start gap-1.5 font-sans">
                        <MapPin className="h-4 w-4 text-slate-500 shrink-0 mt-0.5" />
                        <span className="text-slate-405 leading-tight">{hospital.location}</span>
                      </p>
                      <p className="flex items-center gap-1.5 font-sans">
                        <Phone className="h-4 w-4 text-slate-500 shrink-0" />
                        <span className="text-slate-405 font-mono font-medium">{hospital.phone}</span>
                      </p>
                    </div>

                    {/* Wait Status Badges row */}
                    <div className="mt-4 pt-4 border-t border-white/5 grid grid-cols-2 gap-3 bg-white/5 p-2.5 rounded-xl">
                      <div>
                        <p className="text-[9px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                          {language === 'en' ? 'Estimated Wait' : language === 'hi' ? 'अनुमानित कतार' : language === 'te' ? 'వేచి ఉండే సమయం' : language === 'ta' ? 'காத்திருப்பு நேரம்' : 'പ്രതീക്ഷിത സമയം'}
                        </p>
                        <p className="text-sm font-sans font-extrabold text-cyan-400 mt-0.5 flex items-center gap-1">
                          <Clock className="h-3.5 w-3.5 shrink-0" />
                          {avgWait}
                        </p>
                      </div>
                      <div>
                        <p className="text-[9px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                          {language === 'en' ? 'Patients in Queue' : language === 'hi' ? 'कतार में मरीज' : language === 'te' ? 'క్యూలో రోగులు' : language === 'ta' ? 'வரிசையில் நோயாளிகள்' : 'ക്യൂവിലുള്ള രോഗികൾ'}
                        </p>
                        <p className="text-sm font-sans font-extrabold text-slate-200 mt-0.5">
                          {waitingCount} {language === 'en' ? 'Active' : language === 'hi' ? 'सक्रिय' : language === 'te' ? 'క్రీయాశీలక' : language === 'ta' ? 'செயலில்' : 'സജീവം'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Buttons */}
                <div className="p-5 pt-0 flex gap-2">
                  <button
                    onClick={() => onSelectHospital(hospital)}
                    className="flex-1 text-slate-200 bg-white/5 hover:bg-white/10 border border-white/5 text-xs font-bold py-2.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>{language === 'en' ? 'View Clinicians' : language === 'hi' ? 'चिकित्सक देखें' : language === 'te' ? 'వైద్యులను చూడండి' : language === 'ta' ? 'மருத்துவர்களைப் பார்' : 'ഡോക്ടർമാരെ കാണുക'}</span>
                  </button>
                  <button
                    onClick={() => onBookTokenClick(hospital)}
                    className="flex-1 bg-cyan-500 text-[#0a0c10] hover:bg-cyan-400 text-xs font-bold py-2.5 px-3 rounded-xl transition-all shadow-md flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>{t.book_token}</span>
                    <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Empty State */
        <div className="text-center bg-[#0f1218] border border-white/5 rounded-2xl p-12" id="hospital-empty-state">
          <Building className="h-12 w-12 text-slate-600 mx-auto" />
          <h4 className="mt-3 font-serif italic text-slate-200">
            {language === 'en' ? 'No facilities found' : language === 'hi' ? 'कोई सुविधा नहीं मिली' : language === 'te' ? 'ఎలాంటి సదుపాయాలు లభించలేదు' : language === 'ta' ? 'வசதிகள் எதுவும் இல்லை' : 'ഡാറ്റ ലഭ്യമല്ല'}
          </h4>
          <p className="mt-1 text-xs text-slate-500 max-w-sm mx-auto">
            Try revising your keywords or check another category.
          </p>
          <button
            onClick={() => { setSearchQuery(''); setSelectedCategory('All'); }}
            className="mt-4 px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-bold rounded-xl transition-colors cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      )}
    </div>
  );
}
