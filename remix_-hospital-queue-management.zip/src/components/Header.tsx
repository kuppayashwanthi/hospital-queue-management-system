import React from 'react';
import { Activity, User, LogOut, HeartPulse, RefreshCw, Languages } from 'lucide-react';
import { UserRole, PatientProfile, StaffProfile } from '../types';
import { LanguageType } from '../lib/translations';

interface HeaderProps {
  currentRole: UserRole;
  patientProfile?: PatientProfile;
  staffProfile?: StaffProfile;
  onLogout: () => void;
  onSwitchToGuest: () => void;
  syncTime: string;
  language: LanguageType;
  onLanguageChange: (lang: LanguageType) => void;
}

export default function Header({
  currentRole,
  patientProfile,
  staffProfile,
  onLogout,
  onSwitchToGuest,
  syncTime,
  language,
  onLanguageChange
}: HeaderProps) {
  const languagesList: { code: LanguageType; name: string }[] = [
    { code: 'en', name: 'EN' },
    { code: 'hi', name: 'हिंदी' },
    { code: 'te', name: 'తెలుగు' },
    { code: 'ta', name: 'தமிழ்' },
    { code: 'ml', name: 'മലയാളം' }
  ];

  return (
    <header className="bg-[#0f1218] border-b border-white/10 sticky top-0 z-40 transition-all duration-300 shadow-xl" id="app-header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          {/* Logo Brand */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={onSwitchToGuest}>
            <div className="p-2 sm:p-2.5 bg-cyan-500 text-[#0a0c10] rounded-xl shadow-lg shadow-cyan-500/10 flex items-center justify-center animate-pulse">
              <HeartPulse className="h-5 sm:h-6 w-5 sm:w-6" />
            </div>
            <div>
              <span className="font-serif italic tracking-wide text-lg sm:text-xl text-white flex items-center gap-1">
                CareQueue
                <span className="text-cyan-400 font-extrabold text-2xl leading-none font-sans">.</span>
              </span>
              <p className="text-[9px] sm:text-[10px] font-mono text-slate-500 tracking-[0.2em] uppercase -mt-0.5 sm:-mt-1 hidden xs:block">
                SOPHISTICATED CLINIC CUE
              </p>
            </div>
          </div>

          {/* Sync Status Flag */}
          <div className="hidden md:flex items-center space-x-2 text-[10px] font-mono px-3 py-1.5 bg-white/5 text-slate-300 rounded-lg border border-white/5">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
            </span>
            <span className="uppercase tracking-wider">
              {language === 'en' && 'LIVE DATA SYNC ACTIVE'}
              {language === 'hi' && 'लाइव डेटा सिंक सक्रिय'}
              {language === 'te' && 'లైవ్ సింక్ యాక్టివ్'}
              {language === 'ta' && 'நேரடி ஒத்திசைவு'}
              {language === 'ml' && 'ലൈവ് സമന്വയം'}
            </span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-405">CLOCK: {syncTime}</span>
          </div>

          {/* User Profiles & Language Dropdown */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            {/* Elegant Language Selector */}
            <div className="relative flex items-center bg-white/5 border border-white/10 rounded-xl px-2 py-1 gap-1.5 focus-within:border-cyan-500/50 transition-all">
              <Languages className="h-3.5 w-3.5 text-cyan-400 shrink-0" />
              <select
                value={language}
                onChange={(e) => onLanguageChange(e.target.value as LanguageType)}
                className="bg-transparent text-slate-200 text-xs font-semibold focus:outline-none cursor-pointer pr-1"
                title="Select Language"
              >
                {languagesList.map((lang) => (
                  <option key={lang.code} value={lang.code} className="bg-[#0f1218] text-slate-200">
                    {lang.name}
                  </option>
                ))}
              </select>
            </div>

            {currentRole === 'patient' && patientProfile && (
              <div className="flex items-center space-x-2.5 bg-[#14181f] pl-3 pr-2 py-1 sm:py-1.5 rounded-xl border border-white/5">
                <div className="hidden xs:block text-right">
                  <p className="text-[9px] font-mono font-bold text-cyan-400 uppercase tracking-widest leading-none">
                    {language === 'en' && 'ACTIVE PATIENT'}
                    {language === 'hi' && 'सक्रिय मरीज'}
                    {language === 'te' && 'సక్రియ రోగి'}
                    {language === 'ta' && 'செயலில் நோயாளி'}
                    {language === 'ml' && 'സജീവ രോഗി'}
                  </p>
                  <p className="text-xs sm:text-sm font-sans font-semibold text-slate-200 truncate max-w-[120px]">{patientProfile.name}</p>
                </div>
                <button
                  onClick={onLogout}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
                  title="Logout patient"
                  id="header-logout-patient"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            )}

            {currentRole === 'staff' && staffProfile && (
              <div className="flex items-center space-x-2.5 bg-[#14181f] pl-3 pr-2 py-1 sm:py-1.5 rounded-xl border border-cyan-500/20">
                <div className="hidden xs:block text-right">
                  <p className="text-[9px] font-mono font-bold text-cyan-400 uppercase tracking-widest leading-none">STAFF ADMIN</p>
                  <p className="text-xs sm:text-sm font-sans font-semibold text-slate-200 truncate max-w-[120px]">{staffProfile.staffName}</p>
                </div>
                <button
                  onClick={onLogout}
                  className="p-1.5 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10 rounded-lg transition-colors cursor-pointer"
                  title="Sign out of Admin Panel"
                  id="header-logout-staff"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            )}

            {currentRole === 'guest' && (
              <div className="flex items-center space-x-1.5 sm:space-x-2 text-slate-400 bg-white/5 px-3 py-1.5 rounded-xl border border-white/5">
                <div className="p-0.5">
                  <User className="h-3.5 w-3.5 text-slate-500" />
                </div>
                <span className="text-xs font-mono uppercase tracking-wider text-slate-400">
                  {language === 'en' && 'UNREGISTERED'}
                  {language === 'hi' && 'अस्वीकृत'}
                  {language === 'te' && 'నమోదు కాలేదు'}
                  {language === 'ta' && 'பதிவு செய்யாத'}
                  {language === 'ml' && 'രജിസ്റ്റർ ചെയ്യാത്ത'}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
