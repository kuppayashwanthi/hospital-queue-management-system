import React, { useState } from 'react';
import { User, ShieldAlert, CheckCircle2, ChevronRight, Stethoscope, Sparkles } from 'lucide-react';
import { INITIAL_HOSPITALS } from '../data';
import { PatientProfile, StaffProfile } from '../types';

interface LoginViewProps {
  onPatientLogin: (profile: PatientProfile) => void;
  onStaffLogin: (profile: StaffProfile) => void;
}

export default function LoginView({ onPatientLogin, onStaffLogin }: LoginViewProps) {
  const [activeTab, setActiveTab] = useState<'patient' | 'staff'>('patient');

  // Patient State
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');

  // Staff State
  const [selectedHospitalId, setSelectedHospitalId] = useState(INITIAL_HOSPITALS[0].id);
  const [selectedDeptId, setSelectedDeptId] = useState(INITIAL_HOSPITALS[0].departments[0].id);
  const [staffName, setStaffName] = useState('');

  const currentHospital = INITIAL_HOSPITALS.find(h => h.id === selectedHospitalId) || INITIAL_HOSPITALS[0];

  const handleHospitalChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const hospId = e.target.value;
    setSelectedHospitalId(hospId);
    const hosp = INITIAL_HOSPITALS.find(h => h.id === hospId);
    if (hosp && hosp.departments.length > 0) {
      setSelectedDeptId(hosp.departments[0].id);
    }
  };

  const handlePatientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim()) return;
    // Basic phone formatting simulation or check
    if (!patientPhone.trim()) return;
    onPatientLogin({
      name: patientName.trim(),
      phone: patientPhone.trim()
    });
  };

  const handleStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffName.trim()) return;
    onStaffLogin({
      hospitalId: selectedHospitalId,
      departmentId: selectedDeptId,
      staffName: staffName.trim()
    });
  };

  // Helper to prefill names for testing to make it delightfully frictionless
  const selectQuickProfile = (role: 'patient' | 'staff', name: string, phoneOrDept?: string) => {
    if (role === 'patient') {
      setPatientName(name);
      setPatientPhone(phoneOrDept || '');
    } else {
      setStaffName(name);
      if (phoneOrDept) {
        // Find hospital of that department
        for (const hosp of INITIAL_HOSPITALS) {
          const dept = hosp.departments.find(d => d.id === phoneOrDept);
          if (dept) {
            setSelectedHospitalId(hosp.id);
            setSelectedDeptId(dept.id);
            break;
          }
        }
      }
    }
  };

  return (
    <div className="max-w-2xl mx-auto my-6 sm:my-12 px-4" id="login-container">
      {/* Welcome Hero Headers */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center space-x-1.5 bg-[#14181f] px-3 py-1 rounded-full border border-white/5 text-cyan-400 text-xs font-semibold mb-3">
          <Sparkles className="h-3 w-3 text-cyan-500 animate-spin" />
          <span>CareQueue Patient & Staff Gateways</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-serif italic text-white tracking-tight leading-tight">
          Welcome to <span className="text-cyan-400">CareQueue</span>
        </h1>
        <p className="mt-2 text-slate-400 font-sans text-sm sm:text-base max-w-lg mx-auto">
          Avoid congested waiting rooms. Book high-fidelity digital queue tickets, check real-time estimated doctor timers, and sync live.
        </p>
      </div>

      <div className="bg-[#0f1218] rounded-3xl border border-white/5 shadow-2xl overflow-hidden">
        {/* Toggle Controls */}
        <div className="flex border-b border-white/5 bg-[#14181f]/40 p-2">
          <button
            onClick={() => setActiveTab('patient')}
            className={`flex-1 py-3 text-center rounded-2xl text-sm font-sans font-bold transition-all duration-300 flex items-center justify-center space-x-2 cursor-pointer ${
              activeTab === 'patient'
                ? 'bg-[#0f1218] text-white shadow-md border border-white/5'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            id="tab-select-patient"
          >
            <User className="h-4 w-4" />
            <span>Patient Portal</span>
          </button>
          <button
            onClick={() => setActiveTab('staff')}
            className={`flex-1 py-3 text-center rounded-2xl text-sm font-sans font-bold transition-all duration-300 flex items-center justify-center space-x-2 cursor-pointer ${
              activeTab === 'staff'
                ? 'bg-[#0f1218] text-white shadow-md border border-white/5'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            id="tab-select-staff"
          >
            <Stethoscope className="h-4 w-4" />
            <span>Staff Admin Panel</span>
          </button>
        </div>

        <div className="p-6 sm:p-8">
          {activeTab === 'patient' ? (
            /* Patient Login Form */
            <form onSubmit={handlePatientSubmit} className="space-y-5" id="form-patient-login">
              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Full Patient Name
                </label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-500">
                    <User className="h-5 w-5" />
                  </span>
                  <input
                    type="text"
                    required
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder="e.g. Olivia Wilde"
                    className="w-full bg-[#14181f] border border-white/5 rounded-xl py-3 pl-10 pr-4 font-sans text-sm focus:border-cyan-500 focus:bg-[#1a202a] text-slate-100 outline-none transition-all placeholder-slate-500"
                    id="input-patient-name"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Mobile Number (For Ticket Identification)
                </label>
                <input
                  type="text"
                  required
                  value={patientPhone}
                  onChange={(e) => setPatientPhone(e.target.value)}
                  placeholder="e.g. +1 (555) 123-4567"
                  className="w-full bg-[#14181f] border border-white/5 rounded-xl py-3 px-4 font-sans text-sm focus:border-cyan-500 focus:bg-[#1a202a] text-slate-100 outline-none transition-all placeholder-slate-500"
                  id="input-patient-phone"
                />
                <p className="mt-1.5 text-[11px] text-slate-500 flex items-start gap-1">
                  <ShieldAlert className="h-3.5 w-3.5 shrink-0 text-slate-500 mt-0.5" />
                  We only use this to bundle and query your active digital waiting codes on this browser.
                </p>
              </div>

              <button
                type="submit"
                className="w-full bg-cyan-500 hover:bg-cyan-600 active:scale-[0.98] text-[#0a0c10] font-sans font-bold py-3 px-4 rounded-xl shadow-md shadow-cyan-500/10 hover:shadow-cyan-500/20 transition-all text-sm flex items-center justify-center space-x-2 cursor-pointer"
                id="btn-patient-login-submit"
              >
                <span>Access Digital Queues</span>
                <ChevronRight className="h-4 w-4" />
              </button>

              {/* Patient Quick Profiles */}
              <div className="pt-4 border-t border-white/5">
                <p className="text-[11px] font-mono text-slate-500 font-bold uppercase tracking-wider mb-2.5">
                  Frictionless Quick-Select Profiles (For Testing)
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => selectQuickProfile('patient', 'Olivia Watson', '+1 (555) 765-4321')}
                    className="p-2.5 bg-[#14181f] hover:bg-[#1a202a] text-left rounded-xl border border-white/5 text-xs font-sans font-medium text-slate-300 transition-colors flex flex-col cursor-pointer"
                  >
                    <span className="font-semibold text-slate-200">Olivia Watson (GM-303)</span>
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5">Active Ticket Waiting</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => selectQuickProfile('patient', 'Arthur Dent', '+1 (555) 424-2424')}
                    className="p-2.5 bg-[#14181f] hover:bg-[#1a202a] text-left rounded-xl border border-white/5 text-xs font-sans font-medium text-slate-300 transition-colors flex flex-col cursor-pointer"
                  >
                    <span className="font-semibold text-slate-200">Arthur Dent (ER-501)</span>
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5">Active ER Urgent queue</span>
                  </button>
                </div>
              </div>
            </form>
          ) : (
            /* Staff Login Form */
            <form onSubmit={handleStaffSubmit} className="space-y-5" id="form-staff-login">
              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Select Hospital Facility
                </label>
                <select
                  value={selectedHospitalId}
                  onChange={handleHospitalChange}
                  className="w-full bg-[#14181f] text-slate-100 border border-white/5 rounded-xl py-3 px-3 font-sans text-sm focus:border-cyan-500 focus:bg-[#1a202a] outline-none transition-all"
                  id="select-staff-hospital"
                >
                  {INITIAL_HOSPITALS.map((hospital) => (
                    <option key={hospital.id} value={hospital.id} className="bg-[#14181f] text-slate-100">
                      {hospital.name} ({hospital.departments.length} Depts)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Assign to Clinic Department
                </label>
                <select
                  value={selectedDeptId}
                  onChange={(e) => setSelectedDeptId(e.target.value)}
                  className="w-full bg-[#14181f] text-slate-100 border border-white/5 rounded-xl py-3 px-3 font-sans text-sm focus:border-cyan-500 focus:bg-[#1a202a] outline-none transition-all"
                  id="select-staff-dept"
                >
                  {currentHospital.departments.map((dept) => (
                    <option key={dept.id} value={dept.id} className="bg-[#14181f] text-slate-100">
                      {dept.name} ({dept.doctorName} • {dept.roomNumber})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Staff Identity Header / Name
                </label>
                <input
                  type="text"
                  required
                  value={staffName}
                  onChange={(e) => setStaffName(e.target.value)}
                  placeholder="e.g. Nurse Practitioner Vance"
                  className="w-full bg-[#14181f] border border-white/5 rounded-xl py-3 px-4 font-sans text-sm focus:border-cyan-500 focus:bg-[#1a202a] text-slate-100 outline-none transition-all placeholder-slate-500"
                  id="input-staff-name"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-white hover:bg-slate-100 active:scale-[0.98] text-[#0a0c10] font-sans font-bold py-3 px-4 rounded-xl shadow-md transition-all text-sm flex items-center justify-center space-x-2 cursor-pointer"
                id="btn-staff-login-submit"
              >
                <span>Initialize Admin Dashboard</span>
                <ChevronRight className="h-4 w-4" />
              </button>

              {/* Staff Quick selection profiles */}
              <div className="pt-4 border-t border-white/5">
                <p className="text-[11px] font-mono text-slate-500 font-bold uppercase tracking-wider mb-2.5">
                  Quick-Access Staff Channels (For Testing)
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => selectQuickProfile('staff', 'Dr. Sarah Vance', 'dept-gen-med')}
                    className="p-2.5 bg-[#14181f] hover:bg-[#1a202a] text-left rounded-xl border border-white/5 text-xs font-sans font-medium text-slate-300 transition-colors flex flex-col cursor-pointer"
                  >
                    <span className="font-semibold text-slate-200">Dr. Sarah Vance</span>
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5">Evergreen Gen Medicine</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => selectQuickProfile('staff', 'Dr. Marcus Brody', 'dept-peds-gen')}
                    className="p-2.5 bg-[#14181f] hover:bg-[#1a202a] text-left rounded-xl border border-white/5 text-xs font-sans font-medium text-slate-200 transition-colors flex flex-col cursor-pointer"
                  >
                    <span className="font-semibold text-slate-200">Dr. Marcus Brody</span>
                    <span className="text-[10px] text-slate-500 font-mono mt-0.5">Hope Pediatrics</span>
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
