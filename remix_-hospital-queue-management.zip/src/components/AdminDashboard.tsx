import React, { useState, useEffect } from 'react';
import { Clock, Users, ArrowUpRight, CheckCircle2, Volume2, ShieldAlert, BadgeX, Play, AlertCircle, Ban, CheckSquare, Sparkles, Send } from 'lucide-react';
import { StaffProfile, Token, QueueAnnouncement, TokenStatus } from '../types';
import { loadQueueState, saveQueueState, updateTokenStatus, getActiveQueue } from '../lib/queueEngine';
import { INITIAL_HOSPITALS } from '../data';

interface AdminDashboardProps {
  staffProfile: StaffProfile;
  syncTime: string;
}

export default function AdminDashboard({ staffProfile, syncTime }: AdminDashboardProps) {
  const [tokens, setTokens] = useState<Token[]>([]);
  const [announcements, setAnnouncements] = useState<QueueAnnouncement[]>([]);
  const [customDelayMsg, setCustomDelayMsg] = useState('');
  const [delayNotice, setDelayNotice] = useState<string | null>(null);

  // Load state and listen to updates
  const reloadData = () => {
    const state = loadQueueState();
    setTokens(state.tokens);
    setAnnouncements(state.announcements);
  };

  useEffect(() => {
    reloadData();
    // Poll updates or sync with storage event
    const interval = setInterval(reloadData, 1800);
    
    // Custom storage event triggers update
    window.addEventListener('storage_state_update', reloadData);
    return () => {
      clearInterval(interval);
      window.removeEventListener('storage_state_update', reloadData);
    };
  }, []);

  // Filter department's hospital details
  const hospital = INITIAL_HOSPITALS.find(h => h.id === staffProfile.hospitalId);
  const department = hospital?.departments.find(d => d.id === staffProfile.departmentId);

  // Filter token lists
  const deptTokens = tokens.filter(
    t => t.hospitalId === staffProfile.hospitalId && t.departmentId === staffProfile.departmentId
  );

  const waitingTokens = deptTokens
    .filter(t => t.status === 'waiting')
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  const callingToken = deptTokens.find(t => t.status === 'calling');

  const completedToday = deptTokens.filter(t => t.status === 'completed').length;
  const skippedToday = deptTokens.filter(t => t.status === 'skipped').length;

  // Actions
  const handleCallNext = () => {
    if (waitingTokens.length === 0) {
      alert('There are no waiting patients currently in the department queue.');
      return;
    }

    // If a patient is already calling, auto-complete them or alert
    if (callingToken) {
      const confirmCompletion = window.confirm(
        `Token ${callingToken.tokenNumber} (${callingToken.patientName}) is currently being called. Would you like to mark them as Completed before summoning the next patient?`
      );
      if (confirmCompletion) {
        updateTokenStatus(callingToken.id, 'completed');
      } else {
        return;
      }
    }

    // Call first waiting patient
    const nextToken = waitingTokens[0];
    updateTokenStatus(nextToken.id, 'calling');
    reloadData();

    // Trigger local speech output for doctor convenience
    triggerAnnouncementTTS(nextToken.tokenNumber, nextToken.patientName);
  };

  const handleCompleteCurrent = () => {
    if (!callingToken) return;
    updateTokenStatus(callingToken.id, 'completed');
    reloadData();
  };

  const handleSkipCurrent = () => {
    if (!callingToken) return;
    const confirmSkip = window.confirm(`Skip Token ${callingToken.tokenNumber}? This marks them as skipped/no-show.`);
    if (confirmSkip) {
      updateTokenStatus(callingToken.id, 'skipped');
      reloadData();
    }
  };

  const handleManualAction = (tokenId: string, status: TokenStatus) => {
    updateTokenStatus(tokenId, status);
    reloadData();
  };

  // Trigger TTS voice speaker
  const triggerAnnouncementTTS = (tokenNum: string, patientName: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const text = `Calling Token, ${tokenNum.split('').join(' ')}, ${patientName}. Please proceed to ${department?.roomNumber || 'Cabin 101'}.`;
      const utterance = new SpeechSynthesisUtterance(text);
      
      const voices = window.speechSynthesis.getVoices();
      const femaleVoice = voices.find(v => v.name.toLowerCase().includes('female') || v.name.toLowerCase().includes('google')) || voices[0];
      if (femaleVoice) utterance.voice = femaleVoice;
      utterance.rate = 0.9;
      
      window.speechSynthesis.speak(utterance);
    }
  };

  const handlePostDelay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customDelayMsg.trim()) return;
    
    // Broadcast delay notice inside the department's queue
    // We can simulate this by mutating localStorage key
    const delayNoticeKey = `hosp_delay_notice_${staffProfile.hospitalId}_${staffProfile.departmentId}`;
    localStorage.setItem(delayNoticeKey, customDelayMsg);
    setDelayNotice(customDelayMsg);
    setCustomDelayMsg('');
    alert('Broadcast sent! Patients tracking this department will see this notification live.');
  };

  const handleClearDelay = () => {
    const delayNoticeKey = `hosp_delay_notice_${staffProfile.hospitalId}_${staffProfile.departmentId}`;
    localStorage.removeItem(delayNoticeKey);
    setDelayNotice(null);
  };

  useEffect(() => {
    const delayNoticeKey = `hosp_delay_notice_${staffProfile.hospitalId}_${staffProfile.departmentId}`;
    const saved = localStorage.getItem(delayNoticeKey);
    if (saved) {
      setDelayNotice(saved);
    }
  }, [staffProfile.hospitalId, staffProfile.departmentId]);

  return (
    <div className="space-y-6" id="staff-admin-dashboard">
      {/* Clinic Facility Banner */}
      <div className="bg-[#0f1218] rounded-3xl border border-white/5 p-6 shadow-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <span className="text-[10px] uppercase font-mono font-bold text-cyan-400 bg-cyan-500/10 px-2.5 py-1 rounded-md border border-cyan-500/10">
            Assigned Facility Station
          </span>
          <h2 className="text-2xl font-serif italic text-white tracking-tight mt-2 inline-flex items-center gap-1.5 font-medium">
            {hospital?.name}
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Division: <strong className="text-slate-200">{department?.name}</strong> • Host: <strong className="text-slate-200">{department?.doctorName}</strong> • {department?.roomNumber}
          </p>
        </div>

        <div className="text-xs text-right text-slate-400 font-mono bg-[#14181f]/80 border border-white/5 p-2.5 rounded-xl">
          <p>Sync Ticker: <span className="text-cyan-400">{syncTime}</span></p>
          <p>Active Staff: <span className="text-slate-200">{staffProfile.staffName}</span></p>
        </div>
      </div>

      {/* 4 KPIs grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" id="staff-kpis-grid">
        <div className="bg-[#0f1218] p-5 rounded-2xl border border-white/5 shadow-md">
          <div className="flex justify-between items-start text-cyan-455">
            <Users className="h-5 w-5 text-cyan-400" />
            <span className="text-[10px] font-mono font-bold bg-cyan-500/10 px-1.5 py-0.5 rounded text-cyan-400">Active</span>
          </div>
          <p className="mt-2 text-2xl font-mono font-extrabold text-white">{waitingTokens.length + (callingToken ? 1 : 0)}</p>
          <p className="text-xs text-slate-500 font-sans mt-0.5">Total in Queue</p>
        </div>

        <div className="bg-[#0f1218] p-5 rounded-2xl border border-white/5 shadow-md">
          <div className="flex justify-between items-start text-sky-400">
            <Clock className="h-5 w-5 text-sky-400" />
            <span className="text-[10px] font-mono font-bold bg-sky-500/10 px-1.5 py-0.5 rounded text-sky-400">Est. Mins</span>
          </div>
          <p className="mt-2 text-2xl font-mono font-extrabold text-white">
            {(waitingTokens.length + (callingToken ? 1 : 0)) * (department?.baseTimeMins || 10)}
          </p>
          <p className="text-xs text-slate-500 font-sans mt-0.5">Total Backlog Wait</p>
        </div>

        <div className="bg-[#0f1218] p-5 rounded-2xl border border-white/5 shadow-md">
          <div className="flex justify-between items-start text-emerald-400">
            <CheckCircle2 className="h-5 w-5 text-emerald-400" />
            <span className="text-[10px] font-mono font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded text-emerald-400">Concluded</span>
          </div>
          <p className="mt-2 text-2xl font-mono font-extrabold text-[#10b981]">{completedToday}</p>
          <p className="text-xs text-slate-500 font-sans mt-0.5">Concluded Consultations</p>
        </div>

        <div className="bg-[#0f1218] p-5 rounded-2xl border border-white/5 shadow-md">
          <div className="flex justify-between items-start text-slate-400">
            <BadgeX className="h-5 w-5 text-slate-400" />
            <span className="text-[10px] font-mono font-bold bg-slate-800 px-1.5 py-0.5 rounded text-slate-400">Skipped</span>
          </div>
          <p className="mt-2 text-2xl font-mono font-extrabold text-slate-350">{skippedToday}</p>
          <p className="text-xs text-slate-505 font-sans mt-0.5">Skipped No-shows</p>
        </div>
      </div>

      {/* Main Admin Controller Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="admin-main-section">
        
        {/* Left Column: Call Actions + Active caller */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-[#0f1218] rounded-3xl border border-white/5 p-6 shadow-2xl space-y-5">
            <h3 className="font-serif italic text-white text-base flex items-center gap-1.5">
              <Sparkles className="h-4.5 w-4.5 text-cyan-400" />
              Queue Flow Control
            </h3>

            {/* CALL NEXT CTA BUTTON */}
            <button
              onClick={handleCallNext}
              disabled={waitingTokens.length === 0}
              className="w-full bg-cyan-500 hover:bg-cyan-400 disabled:bg-slate-800 disabled:text-slate-550 disabled:cursor-not-allowed text-[#0a0c10] text-sm font-bold p-4 rounded-xl shadow-lg shadow-cyan-500/10 cursor-pointer flex flex-col items-center justify-center space-y-1 transition-all"
              id="admin-btn-call-next"
            >
              <Volume2 className="h-6 w-6 text-[#0a0c10] animate-pulse" />
              <span className="font-extrabold">Call Next Patient</span>
              {waitingTokens.length > 0 && (
                <span className="text-[10px] opacity-90 uppercase tracking-widest font-mono font-extrabold text-slate-900">
                  Queue Token: {waitingTokens[0].tokenNumber} is next
                </span>
              )}
            </button>

            {/* Currently serving ticket widget */}
            {callingToken ? (
              <div className="bg-[#14181f] border border-white/5 rounded-2xl p-4 text-center space-y-3 shadow-md">
                <div>
                  <span className="text-[9px] uppercase font-bold font-mono tracking-wider text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/10">
                    Serving Now
                  </span>
                  <div className="text-3xl font-mono font-extrabold text-cyan-400 mt-1">
                    {callingToken.tokenNumber}
                  </div>
                  <p className="text-xs font-sans font-bold text-slate-205 mt-0.5">{callingToken.patientName}</p>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <button
                    onClick={handleCompleteCurrent}
                    className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-extrabold transition-all cursor-pointer"
                  >
                    Complete
                  </button>
                  <button
                    onClick={handleSkipCurrent}
                    className="p-2 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl text-xs font-extrabold border border-white/5 transition-all cursor-pointer"
                  >
                    Skip
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-[#14181f]/40 border border-dashed border-white/10 rounded-2xl p-6 text-center text-slate-500 text-xs">
                <AlertCircle className="h-6 w-6 mx-auto text-slate-600 mb-2" />
                No patients currently being called. Click 'Call Next' to summon a patient from the waiting list.
              </div>
            )}
          </div>

          {/* Broadcast notice channel form */}
          <div className="bg-[#0f1218] rounded-3xl border border-white/5 p-6 shadow-2xl">
            <h4 className="font-serif italic text-white text-sm mb-3">
              Broadcast Delay / Alert Ticker
            </h4>
            
            {delayNotice && (
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl mb-3 text-xs flex justify-between items-start">
                <span className="font-medium">Active: {delayNotice}</span>
                <button onClick={handleClearDelay} className="text-[10px] underline font-bold cursor-pointer hover:text-amber-300 ml-1 shrink-0">Clear</button>
              </div>
            )}

            <form onSubmit={handlePostDelay} className="space-y-2">
              <input
                type="text"
                required
                value={customDelayMsg}
                onChange={(e) => setCustomDelayMsg(e.target.value)}
                placeholder="e.g. Dr. delayed by 15 mins due to trauma."
                className="w-full bg-[#14181f] border border-white/5 rounded-xl py-2 px-3 font-sans text-xs outline-none focus:border-cyan-500 text-slate-250 transition-all placeholder-slate-500"
              />
              <button
                type="submit"
                className="w-full bg-white/5 hover:bg-white/10 text-slate-200 border border-white/5 font-sans font-bold py-2 px-3 rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-1"
              >
                <Send className="h-3 w-3" />
                <span>Publish Announcement</span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Full Queue details list and actions */}
        <div className="lg:col-span-8 bg-[#0f1218] rounded-3xl border border-white/5 p-5 shadow-2xl space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-white/5">
            <div>
              <h3 className="font-serif italic text-white text-base">
                Department Queue Registry
              </h3>
              <p className="text-xs text-slate-400">Total of {deptTokens.length} total tokens checked-in today.</p>
            </div>
            
            <div className="flex gap-1">
              <span className="px-2 py-1 bg-cyan-500/10 text-cyan-400 text-[10px] border border-cyan-500/10 font-mono font-bold uppercase rounded">
                Waiting: {waitingTokens.length}
              </span>
              {callingToken && (
                <span className="px-2 py-1 bg-amber-500/10 text-amber-450 text-[10px] border border-amber-500/10 font-mono font-bold uppercase rounded animate-pulse">
                  Serving: 1
                </span>
              )}
            </div>
          </div>

          {/* Table list representation */}
          {deptTokens.length > 0 ? (
            <div className="overflow-x-auto" id="queue-table-container">
              <table className="w-full min-w-[500px] text-left text-xs font-sans">
                <thead>
                  <tr className="border-b border-white/5 text-slate-400 font-mono font-bold uppercase text-[10px]">
                    <th className="py-2.5">Token Code</th>
                    <th>Patient Detail</th>
                    <th>Booked At</th>
                    <th>Status</th>
                    <th className="text-right">Action Desk</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-300">
                  {deptTokens
                    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()) // latest first
                    .map((tk) => (
                      <tr key={tk.id} className="hover:bg-white/5/20 transition-colors">
                        <td className="py-3 font-mono font-extrabold text-white text-sm">
                          {tk.tokenNumber}
                        </td>
                        <td className="font-sans">
                          <p className="font-semibold text-slate-205">{tk.patientName}</p>
                          <p className="text-[10px] text-slate-500 font-mono">{tk.patientPhone}</p>
                        </td>
                        <td className="font-mono text-slate-400">
                          {new Date(tk.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </td>
                        <td>
                          <span className={`px-2 py-0.5 rounded-sm text-[10px] font-bold border ${
                            tk.status === 'calling' ? 'bg-amber-500/10 text-amber-450 border-amber-500/10 font-mono animate-pulse' :
                            tk.status === 'completed' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/10' :
                            tk.status === 'skipped' ? 'bg-rose-500/10 text-rose-400 border-rose-500/10' :
                            'bg-cyan-500/10 text-cyan-400 border-cyan-500/10'
                          }`}>
                            {tk.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="text-right">
                          <div className="flex gap-1 justify-end">
                            {tk.status === 'waiting' && (
                              <button
                                onClick={() => handleManualAction(tk.id, 'calling')}
                                className="px-2 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/10 rounded-md font-bold text-[10px] transition-colors cursor-pointer"
                              >
                                Call Patient
                              </button>
                            )}
                            {tk.status === 'calling' && (
                              <button
                                onClick={() => handleManualAction(tk.id, 'completed')}
                                className="px-2 py-1 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/10 rounded-md font-bold text-[10px] transition-colors cursor-pointer"
                              >
                                Mark Completed
                              </button>
                            )}
                            {tk.status !== 'completed' && tk.status !== 'skipped' && (
                              <button
                                onClick={() => handleManualAction(tk.id, 'skipped')}
                                className="px-2 py-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/10 rounded-md font-bold text-[10px] transition-colors cursor-pointer"
                                title="Mark as Skipped/No-show"
                              >
                                Skip
                              </button>
                            )}
                            {(tk.status === 'completed' || tk.status === 'skipped') && (
                              <button
                                onClick={() => handleManualAction(tk.id, 'waiting')}
                                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md font-bold text-[10px] transition-colors cursor-pointer"
                                title="Re-enroll patient to waiting queue"
                              >
                                Re-queue
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-10 border border-dashed border-white/10 rounded-2xl text-slate-500 text-xs">
              <Users className="h-8 w-8 text-slate-600 mx-auto mb-2" />
              This division department is empty today. No digital token reservations registered.
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
