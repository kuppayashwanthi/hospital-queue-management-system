import { Hospital, Token } from './types';

export const INITIAL_HOSPITALS: Hospital[] = [
  {
    id: 'hosp-evergreen',
    name: 'Evergreen Valley Medical Center',
    location: '742 Evergreen Dr, Medical District (Sector 4)',
    phone: '+1 (555) 304-4500',
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1587351021355-a479a299d2f9?auto=format&fit=crop&q=80&w=400',
    departments: [
      {
        id: 'dept-gen-med',
        name: 'General Medicine',
        baseTimeMins: 10,
        doctorName: 'Dr. Sarah Vance',
        roomNumber: 'Cabin 101',
        category: 'Primary Care'
      },
      {
        id: 'dept-ortho',
        name: 'Orthopedics & Joint Clinic',
        baseTimeMins: 15,
        doctorName: 'Dr. Robert Chen',
        roomNumber: 'Cabin 105',
        category: 'Bone & Joints'
      },
      {
        id: 'dept-cardio',
        name: 'Cardiology Center',
        baseTimeMins: 20,
        doctorName: 'Dr. Evelyn Martinez',
        roomNumber: 'Cabin 202',
        category: 'Heart Health'
      }
    ]
  },
  {
    id: 'hosp-hope-peds',
    name: 'Hope Pediatrics & Child Care',
    location: '120 Sunset Blvd, Family Heights',
    phone: '+1 (555) 902-1200',
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=400',
    departments: [
      {
        id: 'dept-peds-gen',
        name: 'General Pediatrics',
        baseTimeMins: 12,
        doctorName: 'Dr. Marcus Brody',
        roomNumber: 'Play Cabin A',
        category: 'Child Care'
      },
      {
        id: 'dept-peds-allergy',
        name: 'Pediatric Allergies & Asthma',
        baseTimeMins: 15,
        doctorName: 'Dr. Diana Prince',
        roomNumber: 'Play Cabin B',
        category: 'Immunology'
      }
    ]
  },
  {
    id: 'hosp-summit-cardio',
    name: 'Summit Heart & Vascular Inst.',
    location: '99 Alpine Parkway, Ridgeview',
    phone: '+1 (555) 830-7700',
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=400',
    departments: [
      {
        id: 'dept-summit-vasc',
        name: 'Vascular Medicine',
        baseTimeMins: 18,
        doctorName: 'Dr. Kenji Tanaka',
        roomNumber: 'Suite 300A',
        category: 'Vessels'
      },
      {
        id: 'dept-summit-hypert',
        name: 'Hypertension Care',
        baseTimeMins: 12,
        doctorName: 'Dr. Angela Rossi',
        roomNumber: 'Suite 300B',
        category: 'Blood Pressure'
      }
    ]
  },
  {
    id: 'hosp-metro-er',
    name: 'Metro First-Response Clinic',
    location: '450 Broadway St, City Center',
    phone: '+1 (555) 100-9111',
    rating: 4.6,
    image: 'https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&q=80&w=400',
    departments: [
      {
        id: 'dept-urgent',
        name: 'Urgent Walk-in Care',
        baseTimeMins: 15,
        doctorName: 'Dr. James Cole',
        roomNumber: 'Triage Room 1',
        category: 'Emergency'
      },
      {
        id: 'dept-wound',
        name: 'Minor Injuries & Wound Care',
        baseTimeMins: 12,
        doctorName: 'Dr. Sandra Oh',
        roomNumber: 'Triage Room 2',
        category: 'Minor Surgery'
      }
    ]
  }
];

// Seed initial active tokens to make the clinic look alive
export const INITIAL_TOKENS: Token[] = [
  // Evergreen Valley General Medicine
  {
    id: 'token-seed-1',
    tokenNumber: 'GM-302',
    hospitalId: 'hosp-evergreen',
    hospitalName: 'Evergreen Valley Medical Center',
    departmentId: 'dept-gen-med',
    departmentName: 'General Medicine',
    patientName: 'David Miller',
    patientPhone: '+1 (555) 123-4567',
    status: 'completed',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(), // 2 hours ago
    completedAt: new Date(Date.now() - 3600000 * 1.5).toISOString()
  },
  {
    id: 'token-seed-2',
    tokenNumber: 'GM-303',
    hospitalId: 'hosp-evergreen',
    hospitalName: 'Evergreen Valley Medical Center',
    departmentId: 'dept-gen-med',
    departmentName: 'General Medicine',
    patientName: 'Emma Watson',
    patientPhone: '+1 (555) 765-4321',
    status: 'calling',
    createdAt: new Date(Date.now() - 3600000 * 1.2).toISOString(), // 1.2 hours ago
    calledAt: new Date().toISOString()
  },
  {
    id: 'token-seed-3',
    tokenNumber: 'GM-304',
    hospitalId: 'hosp-evergreen',
    hospitalName: 'Evergreen Valley Medical Center',
    departmentId: 'dept-gen-med',
    departmentName: 'General Medicine',
    patientName: 'James Carter',
    patientPhone: '+1 (555) 678-1234',
    status: 'waiting',
    createdAt: new Date(Date.now() - 1800000).toISOString() // 30 mins ago
  },
  {
    id: 'token-seed-4',
    tokenNumber: 'GM-305',
    hospitalId: 'hosp-evergreen',
    hospitalName: 'Evergreen Valley Medical Center',
    departmentId: 'dept-gen-med',
    departmentName: 'General Medicine',
    patientName: 'Olivia Thompson',
    patientPhone: '+1 (555) 987-6543',
    status: 'waiting',
    createdAt: new Date(Date.now() - 900000).toISOString() // 15 mins ago
  },

  // Hope Pediatrics
  {
    id: 'token-seed-5',
    tokenNumber: 'PD-112',
    hospitalId: 'hosp-hope-peds',
    hospitalName: 'Hope Pediatrics & Child Care',
    departmentId: 'dept-peds-gen',
    departmentName: 'General Pediatrics',
    patientName: 'Leo Smith (Child of Sophia)',
    patientPhone: '+1 (555) 234-8901',
    status: 'calling',
    createdAt: new Date(Date.now() - 3000000).toISOString(),
    calledAt: new Date().toISOString()
  },
  {
    id: 'token-seed-6',
    tokenNumber: 'PD-113',
    hospitalId: 'hosp-hope-peds',
    hospitalName: 'Hope Pediatrics & Child Care',
    departmentId: 'dept-peds-gen',
    departmentName: 'General Pediatrics',
    patientName: 'Mia Johnson (Child of Ryan)',
    patientPhone: '+1 (555) 890-5432',
    status: 'waiting',
    createdAt: new Date(Date.now() - 1200000).toISOString()
  },

  // Metro First-Response Urgent Care
  {
    id: 'token-seed-7',
    tokenNumber: 'ER-501',
    hospitalId: 'hosp-metro-er',
    hospitalName: 'Metro First-Response Clinic',
    departmentId: 'dept-urgent',
    departmentName: 'Urgent Walk-in Care',
    patientName: 'Arthur Dent',
    patientPhone: '+1 (555) 424-2424',
    status: 'waiting',
    createdAt: new Date(Date.now() - 400000).toISOString()
  }
];
