export interface Department {
  id: string;
  name: string;
  baseTimeMins: number; // base active time in mins per patient
  doctorName: string;
  roomNumber: string;
  category: string;
}

export interface Hospital {
  id: string;
  name: string;
  location: string;
  phone: string;
  rating: number;
  image: string;
  departments: Department[];
}

export type TokenStatus = 'waiting' | 'calling' | 'completed' | 'skipped';

export interface Token {
  id: string;
  tokenNumber: string; // e.g. "GEN-102"
  hospitalId: string;
  hospitalName: string;
  departmentId: string;
  departmentName: string;
  patientName: string;
  patientPhone: string;
  status: TokenStatus;
  createdAt: string;
  calledAt?: string;
  completedAt?: string;
}

export interface QueueAnnouncement {
  id: string;
  tokenNumber: string;
  patientName: string;
  roomNumber: string;
  departmentName: string;
  timestamp: string;
}

export type UserRole = 'patient' | 'staff' | 'guest';

export interface PatientProfile {
  name: string;
  phone: string;
}

export interface StaffProfile {
  hospitalId: string;
  departmentId: string;
  staffName: string;
}

export interface AppState {
  tokens: Token[];
  announcements: QueueAnnouncement[];
  currentUser: {
    role: UserRole;
    patient?: PatientProfile;
    staff?: StaffProfile;
  } | null;
}
