import { Token, TokenStatus, QueueAnnouncement } from '../types';
import { INITIAL_TOKENS, INITIAL_HOSPITALS } from '../data';

const STORAGE_KEY = 'hospital_queue_state_v2';

export interface StorageData {
  tokens: Token[];
  announcements: QueueAnnouncement[];
}

export function loadQueueState(): StorageData {
  const dataStr = localStorage.getItem(STORAGE_KEY);
  if (!dataStr) {
    const defaultData: StorageData = {
      tokens: INITIAL_TOKENS,
      announcements: []
    };
    saveQueueState(defaultData);
    return defaultData;
  }
  try {
    return JSON.parse(dataStr);
  } catch (e) {
    console.error('Error parsing queue state, resetting', e);
    const defaultData: StorageData = {
      tokens: INITIAL_TOKENS,
      announcements: []
    };
    saveQueueState(defaultData);
    return defaultData;
  }
}

export function saveQueueState(data: StorageData): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  // Dispatch a local storage event manually in case on same tab to trigger update
  window.dispatchEvent(new Event('storage_state_update'));
}

// Generate the next token number based on department initials
function generateTokenNumber(deptName: string, existingTokens: Token[]): string {
  // Take first letters
  const prefix = deptName
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .substring(0, 3);
  
  // Find highest suffix number of today
  const departmentTokens = existingTokens.filter(t => t.departmentName === deptName);
  let highestNum = 100; // start at 101
  departmentTokens.forEach(t => {
    const parts = t.tokenNumber.split('-');
    if (parts.length === 2) {
      const num = parseInt(parts[1], 10);
      if (!isNaN(num) && num > highestNum) {
        highestNum = num;
      }
    }
  });
  
  return `${prefix}-${highestNum + 1}`;
}

export function bookNewToken(
  hospitalId: string,
  departmentId: string,
  patientName: string,
  patientPhone: string
): Token {
  const state = loadQueueState();
  const hospital = INITIAL_HOSPITALS.find(h => h.id === hospitalId);
  const department = hospital?.departments.find(d => d.id === departmentId);

  if (!hospital || !department) {
    throw new Error('Hospital or Department not found');
  }

  const tokenNumber = generateTokenNumber(department.name, state.tokens);

  const newToken: Token = {
    id: `token-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    tokenNumber,
    hospitalId,
    hospitalName: hospital.name,
    departmentId,
    departmentName: department.name,
    patientName,
    patientPhone,
    status: 'waiting',
    createdAt: new Date().toISOString()
  };

  const updatedTokens = [...state.tokens, newToken];
  saveQueueState({
    ...state,
    tokens: updatedTokens
  });

  return newToken;
}

export function getActiveQueue(hospitalId: string, departmentId: string): Token[] {
  const state = loadQueueState();
  return state.tokens.filter(
    t => t.hospitalId === hospitalId && 
         t.departmentId === departmentId && 
         (t.status === 'waiting' || t.status === 'calling')
  );
}

export function getPatientTokens(patientPhone: string): Token[] {
  const state = loadQueueState();
  // Filter by matching phone or containing phone/name
  return state.tokens.filter(
    t => t.patientPhone.trim() === patientPhone.trim() || 
         (t.patientPhone.replace(/\D/g, '') === patientPhone.replace(/\D/g, '') && patientPhone.length > 5)
  );
}

// Estimates of wait calculations
export interface QueuePositionEstimate {
  position: number; // 0 if currently active, 1 if next, etc.
  estimatedWaitMins: number;
}

export function calculatePositionAndWait(tokenId: string): QueuePositionEstimate {
  const state = loadQueueState();
  const targetToken = state.tokens.find(t => t.id === tokenId);
  
  if (!targetToken) {
    return { position: -1, estimatedWaitMins: 0 };
  }

  if (targetToken.status === 'completed' || targetToken.status === 'skipped') {
    return { position: 0, estimatedWaitMins: 0 };
  }

  if (targetToken.status === 'calling') {
    return { position: 0, estimatedWaitMins: 0 }; // Being served now!
  }

  // Get all active tokens for this department that were created BEFORE targetToken
  const activeDeptTokens = state.tokens
    .filter(
      t => t.hospitalId === targetToken.hospitalId && 
           t.departmentId === targetToken.departmentId && 
           (t.status === 'waiting' || t.status === 'calling')
    )
    .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  // Find index of our targetToken
  const targetIndex = activeDeptTokens.findIndex(t => t.id === tokenId);
  
  if (targetIndex === -1) {
    return { position: -1, estimatedWaitMins: 0 };
  }

  // If there is currently a token being called, index 0 is and stays is the calling token.
  // Those with waiting status behind benefit from checking.
  const hospital = INITIAL_HOSPITALS.find(h => h.id === targetToken.hospitalId);
  const department = hospital?.departments.find(d => d.id === targetToken.departmentId);
  const baseTime = department?.baseTimeMins || 10;

  // Let's count how many "waiting" or "calling" elements are ahead of us
  // The first item (index 0) might be 'calling' or 'waiting'.
  // If we are index 0, position = 0 (or 1 depending on display, we will say "0 people ahead of you").
  // So 'position' is exactly targetIndex.
  const position = targetIndex;
  const estimatedWaitMins = position * baseTime;

  return { position, estimatedWaitMins };
}

export function updateTokenStatus(tokenId: string, status: TokenStatus): void {
  const state = loadQueueState();
  const updatedTokens = state.tokens.map(token => {
    if (token.id === tokenId) {
      const updated: Token = { ...token, status };
      if (status === 'calling') {
        updated.calledAt = new Date().toISOString();
      } else if (status === 'completed') {
        updated.completedAt = new Date().toISOString();
      }
      return updated;
    }
    return token;
  });

  // If calling, create an announcement for TTS/Live visual announcements
  let updatedAnnouncements = state.announcements;
  if (status === 'calling') {
    const calledToken = state.tokens.find(t => t.id === tokenId);
    if (calledToken) {
      const hospital = INITIAL_HOSPITALS.find(h => h.id === calledToken.hospitalId);
      const department = hospital?.departments.find(d => d.id === calledToken.departmentId);
      
      const newAnnouncement: QueueAnnouncement = {
        id: `ann-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        tokenNumber: calledToken.tokenNumber,
        patientName: calledToken.patientName,
        roomNumber: department?.roomNumber || 'Room A',
        departmentName: calledToken.departmentName,
        timestamp: new Date().toISOString()
      };
      
      // Keep only last 10 announcements
      updatedAnnouncements = [newAnnouncement, ...state.announcements].slice(0, 10);
    }
  }

  saveQueueState({
    ...state,
    tokens: updatedTokens,
    announcements: updatedAnnouncements
  });
}
