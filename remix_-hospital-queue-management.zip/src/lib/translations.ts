export type LanguageType = 'en' | 'hi' | 'te' | 'ta' | 'ml';

export interface TranslationSchema {
  // Common/Header
  active_patient: string;
  staff_admin: string;
  unregistered: string;
  sync_active: string;
  live_sync: string;
  clock: string;
  return_to_facilities: string;

  // Hospital List
  select_facility: string;
  booking_subtitle: string;
  search_placeholder: string;
  book_token: string;
  view_tracker: string;
  active_queue: string;
  available_depts: string;

  // Book Token Screen
  schedule_title: string;
  schedule_subtitle: string;
  select_dept: string;
  patient_fullname: string;
  patient_name_placeholder: string;
  contact_phone: string;
  deposit_info: string;
  checkout_btn: string;
  booking_confirmed: string;
  booking_under_text: string;
  ticket_digital_receipt: string;
  position_in_queue: string;
  reg_time: string;
  est_waiting: string;
  track_live_btn: string;
  print_ticket_btn: string;
  download_image_btn: string;

  // PhonePe Panel
  phonepe_secure_checkout: string;
  payee_beneficiary: string;
  amount_due: string;
  select_upi_method: string;
  instant_app_link: string;
  instant_app_desc: string;
  verify_custom_upi: string;
  custom_upi_placeholder: string;
  vpa_enter_desc: string;
  scan_qr_title: string;
  scan_qr_desc: string;
  secure_upi_pin_title: string;
  secure_upi_pin_desc: string;
  auth_secure_pay: string;
  change_method: string;
  processing_upi: string;
  please_do_not_close: string;
  payment_successful: string;
  funds_secured: string;
  debited_from: string;
  paid_to: string;
  upi_ref_id: string;
  auth_at: string;
  issue_digital_receipt: string;

  // Tracker Screen
  token_code: string;
  position_ahead: string;
  est_wait_time: string;
  patients: string;
  mins: string;
  currently_serving_desc: string;
  turn_arrived: string;
  proceed_to: string;
  hear_announcement: string;
  announcing: string;
  check_complete: string;
  wrapped_up: string;
  token_skipped: string;
  token_skipped_desc: string;
  audit_timeline_title: string;
}

export const translations: Record<LanguageType, TranslationSchema> = {
  en: {
    active_patient: "Active Patient",
    staff_admin: "Staff Admin",
    unregistered: "Unregistered",
    sync_active: "Live Data Sync Active",
    live_sync: "LIVE DATA SYNC ACTIVE",
    clock: "CLOCK",
    return_to_facilities: "Return to Facilities",

    select_facility: "Select Medical Facility Station",
    booking_subtitle: "Instant digital queuing & smart OP check-in triage",
    search_placeholder: "Search clinics, hospitals or doctors...",
    book_token: "Book Token Receipt",
    view_tracker: "Track Live Queue",
    active_queue: "Active queues",
    available_depts: "Available clinics",

    schedule_title: "Schedule Queue Ticket",
    schedule_subtitle: "Provide medical details for accurate check-in records. Consultation fee will be debited via PhonePe.",
    select_dept: "Select Clinic / Department Speciality",
    patient_fullname: "Patient Full Name",
    patient_name_placeholder: "e.g. Timothy Vance",
    contact_phone: "Contact Mobile Phone (For UPI verification)",
    deposit_info: "Mandatory Consultation Booking Deposit. Today's hospital OP record entry fee for this clinic is ₹{fee}. Secure payment via PhonePe/UPI is required before generating and queuing your ticket.",
    checkout_btn: "Proceed to PhonePay Secure Checkout",
    booking_confirmed: "Booking Confirmed!",
    booking_under_text: "Your medical check-in active token is secured.",
    ticket_digital_receipt: "CareQueue Digital Token",
    position_in_queue: "Position in Queue",
    reg_time: "Registration Time",
    est_waiting: "Est. Waiting Time",
    track_live_btn: "Track Live Wait Position",
    print_ticket_btn: "Download / Print Ticket",
    download_image_btn: "Download Receipt Ticket (PNG)",

    phonepe_secure_checkout: "Secure Instant UPI Checkout",
    payee_beneficiary: "Payee Beneficiary",
    amount_due: "Amount Due",
    select_upi_method: "Select UPI Transfer Method",
    instant_app_link: "Instant PhonePe App Link",
    instant_app_desc: "This request will launch a secure collect intent directly in your PhonePe app on mobile.",
    verify_custom_upi: "Verify / Custom UPI ID",
    custom_upi_placeholder: "e.g. mobile@ybl",
    vpa_enter_desc: "Enter your valid Virtual Payment Address (VPA) handled by PhonePe (@ybl, @axl, @ibl).",
    scan_qr_title: "Dynamic Scan-Pay Desk Code",
    scan_qr_desc: "Scan using PhonePe, Google Pay, Paytm or any BHIM scanner.",
    secure_upi_pin_title: "Secure UPI PIN Entry",
    secure_upi_pin_desc: "Paying to CareQueue Healthcare Services",
    auth_secure_pay: "Authorize Secure Pay",
    change_method: "Change Method",
    processing_upi: "Processing UPI Transaction",
    please_do_not_close: "Please do not close this browser or reload. Contacting NPCI servers.",
    payment_successful: "Payment Successful",
    funds_secured: "Funds secured by CareQueue Clearing House Desk",
    debited_from: "Debited From",
    paid_to: "Paid To",
    upi_ref_id: "UPI Ref Transaction ID",
    auth_at: "Authorized At",
    issue_digital_receipt: "Issue CareQueue Digital Token Receipt",

    token_code: "Token Code",
    position_ahead: "Position Ahead",
    est_wait_time: "Est. Wait Time",
    patients: "patients",
    mins: "mins",
    currently_serving_desc: "Currently serving and tracking this queue. Please stay nearby. When your token is called, an announcement will broadcast.",
    turn_arrived: "Your Turn Has Arrived!",
    proceed_to: "Please proceed to room {roomNumber}. Doctor {doctorName} is ready for you.",
    hear_announcement: "Hear Room Call Audio Announcement",
    announcing: "Announcing...",
    check_complete: "Check-in Complete",
    wrapped_up: "Thank you for using CareQueue. Your visit to Doctor {doctorName} is wrapped up.",
    token_skipped: "Token Skipped",
    token_skipped_desc: "This queue appointment has been closed or was skipped. Please register a brand new token or consult the front hospital triage desk immediately.",
    audit_timeline_title: "Queue Audit Timeline Logs"
  },
  hi: {
    active_patient: "सक्रिय रोगी",
    staff_admin: "स्टाफ व्यवस्थापक",
    unregistered: "अस्वीकृत",
    sync_active: "लाइव डेटा समन्वय सक्रिय",
    live_sync: "लाइव डेटा समन्वय सक्रिय है",
    clock: "घड़ी",
    return_to_facilities: "अस्पतालों की सूची",

    select_facility: "चिकित्सा सुविधा स्टेशन का चयन करें",
    booking_subtitle: "त्वरित डिजिटल कतारबद्धता और स्मार्ट ओपी चेक-इन",
    search_placeholder: "क्लीनिक, अस्पताल या डॉक्टर खोजें...",
    book_token: "टोकन रसीद बुक करें",
    view_tracker: "लाइव कतार देखें",
    active_queue: "सक्रिय कतारें",
    available_depts: "उपलब्ध क्लीनिक",

    schedule_title: "कतार टिकट बुक करें",
    schedule_subtitle: "सटीक चेक-इन रिकॉर्ड के लिए चिकित्सा विवरण प्रदान करें। परामर्श शुल्क PhonePe के माध्यम से डेबिट किया जाएगा।",
    select_dept: "क्लिनिक / विभाग विशेषता का चयन करें",
    patient_fullname: "मरीज का पूरा नाम",
    patient_name_placeholder: "जैसे: सुमित शर्मा",
    contact_phone: "संपर्क मोबाइल फोन (यूपीआई सत्यापन के लिए)",
    deposit_info: "अनिवार्य परामर्श बुकिंग जमा। आज इस क्लिनिक के लिए ओपी प्रवेश शुल्क ₹{fee} है। टिकट और कतार बुक करने से पहले PhonePe/UPI भुगतान आवश्यक है।",
    checkout_btn: "PhonePe सुरक्षित चेकआउट पर आगे बढ़ें",
    booking_confirmed: "बुकिंग की पुष्टि हो गई!",
    booking_under_text: "आपका चिकित्सा चेक-इन टोकन सुरक्षित रूप से आरक्षित है।",
    ticket_digital_receipt: "केयरक्यू डिजिटल टोकन",
    position_in_queue: "कतार में स्थान",
    reg_time: "पंजीकरण का समय",
    est_waiting: "अनुमानित प्रतीक्षा समय",
    track_live_btn: "लाइव प्रतीक्षा स्थिति देखें",
    print_ticket_btn: "डाउनलोड / प्रिंट टिकट",
    download_image_btn: "टिकट रसीद डाउनलोड करें (PNG)",

    phonepe_secure_checkout: "सुरक्षित त्वरित यूपीआई भुगतान",
    payee_beneficiary: "भुगतान पाने वाला",
    amount_due: "भुगतान राशि",
    select_upi_method: "यूपीआई भुगतान विधि चुनें",
    instant_app_link: "त्वरित PhonePe ऐप लिंक",
    instant_app_desc: "यह अनुरोध सीधे आपके मोबाइल नंबर पर PhonePe ऐप में एक सुरक्षित पेमेंट रिक्वेस्ट भेजेगा।",
    verify_custom_upi: "यूपीआई आईडी सत्यापित करें",
    custom_upi_placeholder: "जैसे: mobile@ybl",
    vpa_enter_desc: "PhonePe (@ybl, @axl, @ibl) द्वारा प्रबंधित अपनी मान्य वर्चुअल भुगतान पता (VPA) दर्ज करें।",
    scan_qr_title: "डायनेमिक स्कैन-पे कोड",
    scan_qr_desc: "PhonePe, Google Pay, Paytm या किसी भी BHIM स्कैनर के माध्यम से स्कैन करें।",
    secure_upi_pin_title: "सुरक्षित यूपीआई पिन दर्ज करें",
    secure_upi_pin_desc: "केयरक्यू स्वास्थ्य सेवाओं को भुगतान किया जा रहा है",
    auth_secure_pay: "सुरक्षित भुगतान अधिकृत करें",
    change_method: "भुगतान विधि बदलें",
    processing_upi: "यूपीआई लेनदेन संसाधित किया जा रहा है",
    please_do_not_close: "कृपया इस ब्राउज़र को बंद या रीलोड न करें। एनपीसीआई सर्वर से कनेक्टिविटी की जा रही है।",
    payment_successful: "भुगतान सफल रहा",
    funds_secured: "केयरक्यू क्लियरिंग हाउस डेस्क द्वारा फंड सुरक्षित रूप से प्राप्त",
    debited_from: "डेबिट किया गया खाता",
    paid_to: "प्राप्तकर्ता",
    upi_ref_id: "यूपीआई रेफ लेनदेन संख्या",
    auth_at: "स्वीकृत समय",
    issue_digital_receipt: "केयरक्यू डिजिटल टोकन रसीद प्राप्त करें",

    token_code: "टोकन कोड",
    position_ahead: "आपके आगे पोजीशन",
    est_wait_time: "अनुमानित प्रतीक्षा",
    patients: "मरीज",
    mins: "मिनट",
    currently_serving_desc: "वर्तमान में इस कतार की सेवा और ट्रैकिंग की जा रही है। कृपया नजदीक ही रहें। जब आपका टोकन बुलाया जाएगा, घोषणा सुनी जाएगी।",
    turn_arrived: "आपकी बारी आ गई है!",
    proceed_to: "कृपया कमरा संख्या {roomNumber} पर जाएं। डॉक्टर {doctorName} आपकी प्रतीक्षा कर रहे हैं।",
    hear_announcement: "कमरा कॉल ऑडियो घोषणा सुनें",
    announcing: "घोषणा की जा रही है...",
    check_complete: "चेक-इन समाप्त हुआ",
    wrapped_up: "केयरक्यू का उपयोग करने के लिए धन्यवाद। डॉक्टर {doctorName} के साथ परामर्श पूरा हो गया है।",
    token_skipped: "टोकन छोड़ दिया गया",
    token_skipped_desc: "यह नियुक्ति कतार से हटा दी गई है। कृपया नया टोकन पंजीकृत करें या तुरंत फ्रंट डेस्क से संपर्क करें।",
    audit_timeline_title: "कतार ऑडिट टाइमलाइन लॉग"
  },
  te: {
    active_patient: "సక్రియ రోగి",
    staff_admin: "స్టాఫ్ అడ్మిన్",
    unregistered: "నమోదు కాలేదు",
    sync_active: "లైవ్ డేటా సమకాలీకరణ సక్రియం లో ఉంది",
    live_sync: "లైవ్ డేటా సమకాలీకరణ కార్యాచరణలో ఉంది",
    clock: "గడియారం",
    return_to_facilities: "ఆసుపత్రుల జాబితా",

    select_facility: "వైద్య సదుపాయం స్టేషన్‌ను ఎంచుకోండి",
    booking_subtitle: "తక్షణ డిజిటల్ క్యూయింగ్ & స్మార్ట్ OP చెక్-ఇన్",
    search_placeholder: "క్లినిక్‌లు, ఆసుపత్రులు లేదా వైద్యులను శోధించండి...",
    book_token: "టోకెన్ బుక్ చేయండి",
    view_tracker: "క్యూ ట్రాక్ చేయండి",
    active_queue: "సక్రియ క్యూస్",
    available_depts: "అందుబాటులో ఉన్న క్లినిక్‌లు",

    schedule_title: "క్యూ టికెట్ షెడ్యూల్ చేయండి",
    schedule_subtitle: "ఖచ్చితమైన చెక్-ఇన్ రికార్డుల కోసం వైద్య వివరాలను అందించండి. రుసుమును PhonePe ద్వారా చెల్లించవచ్చు.",
    select_dept: "క్లినిక్ / డిపార్ట్మెంట్ ప్రత్యేకతను ఎంచుకోండి",
    patient_fullname: "రోగి పూర్తి పేరు",
    patient_name_placeholder: "ఉదా: రమేష్ బాబు",
    contact_phone: "మొబైల్ నంబర్ (UPI ధృవీకరణ కోసం)",
    deposit_info: "తప్పనిసరి సంప్రదింపు రుసుము. ఈ క్లినిక్ ప్రవేశ రుసుము ₹{fee}. టోకెన్ విడుదల అయ్యే ముందు PhonePe/UPI ద్వారా రుసుము నిర్ధారించుకోండి.",
    checkout_btn: "PhonePe సురక్షిత చెల్లింపునకు వెళ్ళండి",
    booking_confirmed: "బుకింగ్ నిర్ధారించబడింది!",
    booking_under_text: "మీ వైద్య చెక్-ఇన్ యాక్టివ్ టోకెన్ సురక్షితంగా రిజర్వ్ చేయబడింది.",
    ticket_digital_receipt: "కేర్-క్యూ డిజిటల్ టోకెన్",
    position_in_queue: "క్యూలో స్థానం",
    reg_time: "నమోదైన సమయం",
    est_waiting: "రీచ్ టైం అంచనా",
    track_live_btn: "లైవ్ పొజిషన్ ట్రాక్ చేయండి",
    print_ticket_btn: "ప్రింట్ / డౌన్‌లోడ్ టికెట్",
    download_image_btn: "రసీదు టోకెన్ డౌన్‌లోడ్ చేయండి (PNG)",

    phonepe_secure_checkout: "సురక్షిత తక్షణ UPI చెల్లింపు",
    payee_beneficiary: "చెల్లింపు స్వీకర్త",
    amount_due: "చెల్లించాల్సిన మొత్తం",
    select_upi_method: "UPI బదిలీ పద్ధతిని ఎంచుకోండి",
    instant_app_link: "క్షణాల్లో PhonePe యాప్ లింక్",
    instant_app_desc: "ఈ అభ్యర్థన నేరుగా మీ మొబైల్ కు PhonePe యాప్‌లో సురక్షిత చెల్లింపు అభ్యర్థనగా వస్తుంది.",
    verify_custom_upi: "UPI ఐడిని ధృవీకరించండి",
    custom_upi_placeholder: "ఉదా: mobile@ybl",
    vpa_enter_desc: "మీ గూగుల్ పే లేదా PhonePe (@ybl, @axl, @ibl) రక్షిత చెల్లింపు చిరునామా నమోదు చేయండి.",
    scan_qr_title: "డైనమిక్ స్కాన్ & పే కోడ్",
    scan_qr_desc: "PhonePe, Google Pay, Paytm లేదా ఏదైనా BHIM స్కానర్ ఉపయోగించి స్కాన్ చేయండి.",
    secure_upi_pin_title: "సురక్షిత UPI పిన్ నమోదు",
    secure_upi_pin_desc: "కేర్-క్యూ హెల్త్‌కేర్ సేవలకు చెల్లించడం జరుగుతోంది",
    auth_secure_pay: "సురక్షిత చెల్లింపు అనుమతించండి",
    change_method: "చెల్లింపు పద్ధతిని మార్చండి",
    processing_upi: "UPI లావాదేవీ ప్రక్రియ జరుగుతోంది",
    please_do_not_close: "దయచేసి బ్రౌజర్ మూసివేయకండి లేదా రీలోడ్ చేయకండి. npc సేవలకు కనెక్ట్ అవుతున్నాము.",
    payment_successful: "చెల్లింపు విజయవంతమైంది",
    funds_secured: "ఫండ్స్ సురక్షితంగా రికార్డ్ చేయబడ్డాయి",
    debited_from: "డెబిట్ చేయబడిన మొబైల్",
    paid_to: "స్వీకర్త పేరు",
    upi_ref_id: "UPI లావాదేవీ సంఖ్య (Ref ID)",
    auth_at: "అనుమతించబడిన సమయం",
    issue_digital_receipt: "టోకెన్ రసీదు జారీ చేయండి",

    token_code: "టోకెన్ కోడ్",
    position_ahead: "మీకు ముందున్న రోగుల సంఖ్య",
    est_wait_time: "వేచి ఉండే అంచనా సమయం",
    patients: "రోగులు",
    mins: "నిమిషాలు",
    currently_serving_desc: "ప్రస్తుతం ఈ క్యూ సేవలు ట్రాక్ చేయబడుతున్నాయి. దయచేసి సమీపంలోనే ఉండండి. మీ టోకెన్ పిలిచినప్పుడు ఇక్కడ వినబడుతుంది.",
    turn_arrived: "మీ వంతు వచ్చింది!",
    proceed_to: "దయచేసి రూమ్ {roomNumber} కి వెళ్ళండి. డాక్టర్ {doctorName} మీ కోసం వేచి ఉన్నారు.",
    hear_announcement: "ఆడియో ప్రకటన వినండి",
    announcing: "ప్రకటిస్తున్నారు...",
    check_complete: "చెక్-ఇన్ పూర్తయింది",
    wrapped_up: "కేర్-క్యూ ఉపయోగించినందుకు ధన్యవాదాలు. డాక్టర్ {doctorName} సంప్రదింపు పూర్తి అయింది.",
    token_skipped: "టోకెన్ దాటవేయబడింది",
    token_skipped_desc: "ఈ టోకెన్ నిలిపివేయబడింది. దయచేసి కొత్త టోకెన్ నమోదు చేసుకోండి లేదా వెంటనే కౌంటర్ ను సంప్రదించండి.",
    audit_timeline_title: "క్యూ ఆడిట్ కాలక్రమం"
  },
  ta: {
    active_patient: "செயலில் உள்ள நோயாளி",
    staff_admin: "பணியாளர் நிர்வாகி",
    unregistered: "பதிவு செய்யப்படவில்லை",
    sync_active: "நேரடி ஒத்திசைவு செயலில் உள்ளது",
    live_sync: "நேரடி தரவு ஒத்திசைவு செயலில் உள்ளது",
    clock: "கடிகாரம்",
    return_to_facilities: "மருத்துவமனைப் பட்டியல்",

    select_facility: "மருத்துவ வசதி நிலையத்தைத் தேர்ந்தெடுக்கவும்",
    booking_subtitle: "உடனடி டிஜிட்டல் வரிசைப்படுத்துதல் & ஸ்மார்ட் ஓபி செக்-இன்",
    search_placeholder: "மருத்துவமனைகள் அல்லது மருத்துவர்களைத் தேடுங்கள்...",
    book_token: "டோக்கன் ரசீது முன்பதிவு",
    view_tracker: "வழியைப் பின்தொடரவும்",
    active_queue: "செயலில் உள்ள வரிசைகள்",
    available_depts: "கிடைக்கக்கூடிய மருத்துவமனைப் பிரிவுகள்",

    schedule_title: "வரிசை டிக்கெட்டைத் திட்டமிடுங்கள்",
    schedule_subtitle: "துல்லியமான செக்-இன் பதிவுகளுக்கு மருத்துவ விவரங்களை வழங்கவும். ஆலோசனைக் கட்டணம் PhonePe மூலம் கழிக்கப்படும்.",
    select_dept: "மருத்துவமனை / துறை சிறப்பைத் தேர்ந்தெடுக்கவும்",
    patient_fullname: "நோயாளியின் முழு பெயர்",
    patient_name_placeholder: "எ.கா: சுந்தர் ராஜன்",
    contact_phone: "தொடர்பு கைபேசி (UPI சரிபார்ப்பிற்கு)",
    deposit_info: "கட்டாய ஆலோசனைக் கட்டண வைப்பு. இந்த ஓபி மருத்துவமனை நுழைவுக் கட்டணம் ₹{fee} ஆகும். முன்பதிவுக்கு முன் PhonePe/UPI மூலம் பணம் செலுத்துவது கட்டாயமாகும்.",
    checkout_btn: "PhonePe பாதுகாப்பான கட்டணத்திற்குச் செல்லவும்",
    booking_confirmed: "முன்பதிவு உறுதி செய்யப்பட்டது!",
    booking_under_text: "உங்களது மருத்துவ செக்-இன் டோக்கன் பாதுகாப்பாக ஒதுக்கப்பட்டது.",
    ticket_digital_receipt: "கேர்கியூ டிஜிட்டல் டோக்கன்",
    position_in_queue: "வரிசையில் உங்களது நிலை",
    reg_time: "பதிவு செய்த நேரம்",
    est_waiting: "மதிப்பிடப்பட்ட காத்திருப்பு",
    track_live_btn: "காத்திருப்பு நிலையைக் கண்காணியுங்கள்",
    print_ticket_btn: "அச்சிடுக / பதிவிறக்குக",
    download_image_btn: "டோக்கன் ரசீதை பதிவிறக்கவும் (PNG)",

    phonepe_secure_checkout: "பாதுகாப்பான உடனடி UPI கட்டணம்",
    payee_beneficiary: "பணம் பெறுபவர்",
    amount_due: "செலுத்த வேண்டிய தொகை",
    select_upi_method: "UPI செலுத்தும் முறையைத் தேர்ந்தெடுங்கள்",
    instant_app_link: "உடனடி PhonePe செயலி இணைப்பு",
    instant_app_desc: "இந்த கோரிக்கை உங்கள் மொபைலில் உள்ள PhonePe செயலியில் நேரடியாக ஒரு பாதுகாப்பான சேகரிப்பு கோரிக்கையைத் தொடங்கும்.",
    verify_custom_upi: "UPI முகவரியை சரிபார்",
    custom_upi_placeholder: "எ.கா: mobile@ybl",
    vpa_enter_desc: "PhonePe (@ybl, @axl, @ibl) ஆல் நிர்வகிக்கப்படும் உங்களது சரியான UPI முகவரியை உள்ளிடவும்.",
    scan_qr_title: "டைனமிக் க்யூஆர் குறியீடு",
    scan_qr_desc: "PhonePe, Google Pay, Paytm அல்லது ஏதேனும் ஒரு BHIM க்யூஆர் ஸ்கேனர் கொண்டு ஸ்கேன் செய்க.",
    secure_upi_pin_title: "பாதுகாப்பான UPI பின் உள்ளீடு",
    secure_upi_pin_desc: "கேர்கியூ மருத்துவ சேவைகளுக்குப் பணம் செலுத்தப்படுகிறது",
    auth_secure_pay: "பாதுகாப்பான கட்டணத்தை அங்கீகரி",
    change_method: "கட்டண முறையை மாற்று",
    processing_upi: "UPI பரிவர்த்தனை செயலாக்கப்படுகிறது",
    please_do_not_close: "தயவுசெய்து இந்த பக்கத்தை மூடவோ மறுஏற்றம் செய்யவோ வேண்டாம். NPCI சர்வர்களுடன் இணைக்கப்படுகிறது.",
    payment_successful: "கட்டணம் வெற்றிகரமாக செலுத்தப்பட்டது",
    funds_secured: "கேர்கியூ மூலம் பணம் பாதுகாப்பாகப் பெறப்பட்டது",
    debited_from: "கழிக்கப்பட்ட கைபேசி எண்",
    paid_to: "பெறுநர்",
    upi_ref_id: "UPI குறிப்பு பரிவர்த்தனை எண்",
    auth_at: "அங்கீகரிக்கப்பட்ட நேரம்",
    issue_digital_receipt: "டோக்கன் ரசீதை வழங்குக",

    token_code: "டோக்கன் குறியீடு",
    position_ahead: "முன்னால் உள்ள நோயாளிகள்",
    est_wait_time: "காத்திருப்பு நேரம்",
    patients: "நோயாளிகள்",
    mins: "நிமிடங்கள்",
    currently_serving_desc: "தற்போது இந்த வரிசையை வழங்கி கண்காணித்து வருகிறது. தயவுசெய்து அருகில் இருங்கள். உங்களது டோக்கன் அழைக்கப்படும் போது அறிவிக்கப்படும்.",
    turn_arrived: "உங்களது முறை வந்துவிட்டது!",
    proceed_to: "தயவுசெய்து அறை எண் {roomNumber} -க்குச் செல்லுங்கள். மருத்துவர் {doctorName} உங்களுக்காகத் தயார் நிலையில் உள்ளார்.",
    hear_announcement: "ஆடியோ அழைப்பைக் கேள்",
    announcing: "அழைப்பு ஒலிக்கிறது...",
    check_complete: "செக்-இன் நிறைவடைந்தது",
    wrapped_up: "கேர்கியூ-வைப் பயன்படுத்தியதற்கு நன்றி. மருத்துவர் {doctorName} உடனான உங்கள் சந்திப்பு நிறைவடைந்தது.",
    token_skipped: "டோக்கன் தவிர்க்கப்பட்டது",
    token_skipped_desc: "இந்த முன்பதிவு வரிசையில் இருந்து தவிர்க்கப்பட்டுள்ளது. தயவுசெய்து புதிய டோக்கனைப் பெறுங்கள் அல்லது உதவி மையத்தை உடனடியாக அணுகவும்.",
    audit_timeline_title: "வரிசை தணிக்கை காலவரிசை"
  },
  ml: {
    active_patient: "സജീവ രോഗി",
    staff_admin: "ജീവനക്കാരുടെ അഡ്മിൻ",
    unregistered: "രജിസ്റ്റർ ചെയ്യാത്ത",
    sync_active: "തത്സമയ സമന്വയം സജീവം",
    live_sync: "തത്സമയ ഡാറ്റ സമന്വയം സജീവമാണ്",
    clock: "ക്ലോക്ക്",
    return_to_facilities: "ആശുപത്രികളുടെ ലിസ്റ്റ്",

    select_facility: "മെഡിക്കൽ ഫെസിലിറ്റി സ്റ്റേഷൻ തിരഞ്ഞെടുക്കുക",
    booking_subtitle: "തൽക്ഷണ ഡിജിറ്റൽ ക്യൂയിംഗും സ്മാർട്ട് ഒപി ചെക്ക്-ഇന്നും",
    search_placeholder: "ക്ലിനിക്കുകൾ, ആശുപത്രികൾ അല്ലെങ്കിൽ ഡോക്ടർമാരെ തിരയുക...",
    book_token: "ടോക്കൺ റസീത് ബുക്ക് ചെയ്യുക",
    view_tracker: "തത്സമയ ക്യൂ ട്രാക്ക് ചെയ്യുക",
    active_queue: "സജീവ ക്യൂകൾ",
    available_depts: "ഉപലബ്ധ ക്ലിനിക്കുകൾ",

    schedule_title: "ക്യൂ ടിക്കറ്റ് ഷെഡ്യൂൾ ചെയ്യുക",
    schedule_subtitle: "കൃത്യമായ ചെക്ക്-ഇൻ റെക്കോർഡുകൾക്കായി മെഡിക്കൽ വിശദാംശങ്ങൾ നൽകുക. ഫീസ് ഫോൺപേ വഴി ഈടാക്കും.",
    select_dept: "ക്ലിനിക് / ഡിപ്പാർട്ട്മെന്റ് സ്പെഷ്യാലിറ്റി തിരഞ്ഞെടുക്കുക",
    patient_fullname: "രോഗിയുടെ മുഴുവൻ പേര്",
    patient_name_placeholder: "ഉദാ: ഹരി പ്രസാദ്",
    contact_phone: "ഫോൺ നമ്പർ (UPI പരിശോധനയ്ക്കായി)",
    deposit_info: "നിർബന്ധിത ഒപി പ്രവേശന ഫീസ്. ഈ ക്ലിനിക്കിലെ പ്രവേശന ഫീസ് ₹{fee} ആണ്. ടോക്കൺ ലഭിക്കുന്നതിന് മുൻപായി PhonePe/UPI പണമടയ്ക്കൽ നിർബന്ധമാണ്.",
    checkout_btn: "സുരക്ഷിത ഫോൺപേ പേയ്‌മെന്റിലേക്ക് പോവുക",
    booking_confirmed: "ബുക്കിംഗ് സ്ഥിരീകരിച്ചു!",
    booking_under_text: "മെഡിക്കൽ ടോക്കൺ സുരക്ഷിതമായി റിസർവ് ചെയ്തിരിക്കുന്നു.",
    ticket_digital_receipt: "കെയർ ക്യൂ ഡിജിറ്റൽ ടോക്കൺ",
    position_in_queue: "ക്യൂവിലെ നിലവിലെ സ്ഥാനം",
    reg_time: "രജിസ്റ്റർ ചെയ്ത സമയം",
    est_waiting: "കാത്തിരിക്കേണ്ട സമയം",
    track_live_btn: "തത്സമയ കാത്തിരിപ്പ് നില ട്രാക്ക് ചെയ്യുക",
    print_ticket_btn: "ടിക്കറ്റ് അച്ചടിക്കുക / ഡൗൺലോഡ് ചെയ്യുക",
    download_image_btn: "ടോക്കൺ റസീത് ഡൗൺലോഡ് ചെയ്യുക (PNG)",

    phonepe_secure_checkout: "സുരക്ഷിത തൽക്ഷണ UPI പേയ്‌മെന്റ്",
    payee_beneficiary: "പണം സ്വീകർത്താവ്",
    amount_due: "അടയ്ക്കേണ്ട തുക",
    select_upi_method: "UPI വിനിമയ രീതി തിരഞ്ഞെടുക്കുക",
    instant_app_link: "തൽക്ഷണ ഫോൺപേ ആപ്പ് ലിങ്ക്",
    instant_app_desc: "ഈ അഭ്യർത്ഥന നിങ്ങളുടെ മൊബൈലിലെ ഫോൺപേ ആപ്പിലേക്ക് ഒരു സുരക്ഷിതCollect ഓർഡർ അയക്കുന്നതാണ്.",
    verify_custom_upi: "UPI ഐഡി പരിശോധിക്കുക",
    custom_upi_placeholder: "ഉദാ: mobile@ybl",
    vpa_enter_desc: "ഫോൺപേ (@ybl, @axl, @ibl) നിയന്ത്രിക്കുന്ന സാധുവായ യുപിഐ വിലാസം നൽകുക.",
    scan_qr_title: "ഡയനാമിക് ക്യുആർ കോഡ്",
    scan_qr_desc: "PhonePe, Google Pay, Paytm അല്ലെങ്കിൽ മറ്റേതെങ്കിലും BHIM ക്യുആർ സ്കാനർ ഉപയോഗിച്ച് സ്കാൻ ചെയ്യുക.",
    secure_upi_pin_title: "സുരക്ഷിത UPI പിൻ നമ്പർ നൽകുക",
    secure_upi_pin_desc: "കെയർ ക്യൂ ഹെൽത്ത്കെയർ സർവീസസിലേക്ക് പണമടയ്ക്കുന്നു",
    auth_secure_pay: "സുരക്ഷിത പണമടയ്ക്കൽ അനുവദിക്കുക",
    change_method: "പണമടയ്ക്കൽ രീതി മാറ്റുക",
    processing_upi: "യുപിഐ വിനിമയം പുരോഗമിക്കുന്നു",
    please_do_not_close: "ദയവായി ഈ വിൻഡോ ക്ലോസ് ചെയ്യുകയോ റീലോഡ് ചെയ്യുകയോ ചെയ്യരുത്. എൻപിസിഐ സെർവറുമായി കണക്ട് ചെയ്യുന്നു.",
    payment_successful: "പണമടയ്ക്കൽ വിജയിച്ചു",
    funds_secured: "കെയർ ക്യൂ ക്ലിയറിംഗ് ഹൗസ് ഡെസ്‌ക് പണം സുരക്ഷിതമായി ലഭിച്ചു",
    debited_from: "പണം ഈടാക്കിയ മൊബൈൽ",
    paid_to: "പണം സ്വീകർത്താവ്",
    upi_ref_id: "UPI റഫറൻസ് വിനിമയ നമ്പർ",
    auth_at: "അംഗീകരിക്കപ്പെട്ട സമയം",
    issue_digital_receipt: "രോഗി ടോക്കൺ റസീത് നൽകുക",

    token_code: "ടോക്കൺ കോഡ്",
    position_ahead: "മുന്നിലുള്ള രോഗികളുടെ എണ്ണം",
    est_wait_time: "കാത്തിരിക്കേണ്ട സമയം",
    patients: "രോഗികൾ",
    mins: "മിനിറ്റ്",
    currently_serving_desc: "നിലവിൽ ഈ ക്യൂ വിവരങ്ങൾ ട്രാക്ക് ചെയ്യപ്പെടുകയാണ്. ദയവായി സമീപത്ത് തന്നെ കാണുക. നിങ്ങളുടെ ടോക്കൺ വിളിക്കുമ്പോൾ അറിയിപ്പ് ലഭിക്കും.",
    turn_arrived: "നിങ്ങളുടെ ഊഴം എത്തിയിരിക്കുന്നു!",
    proceed_to: "ദയവായി മുറി നമ്പർ {roomNumber}-ലേക്ക് പോവുക. ഡോക്ടർ {doctorName} നിങ്ങളെ കാത്തിരിക്കുന്നു.",
    hear_announcement: "വിളിക്കുന്ന ശബ്ദം പ്ലേ ചെയ്യുക",
    announcing: "അറിയിക്കുന്നു...",
    check_complete: "ചെക്ക്-ഇൻ പൂർത്തിയായിരിക്കുന്നു",
    wrapped_up: "കെയർ ക്യൂ ഉപയോഗിച്ചതിന് നന്ദി. ഡോക്ടർ {doctorName}-മായിട്ടുള്ള നിങ്ങളുടെ കൂടിക്കാഴ്ച പൂർത്തിയായിരിക്കുന്നു.",
    token_skipped: "ടോക്കൺ സ്കിപ് ചെയ്യപ്പെട്ടു",
    token_skipped_desc: "ഈ ടോക്കൺ അപ്പോയിന്റ്മെന്റ് ഒഴിവാക്കിയിരിക്കുന്നു. ദയവായി പുതിയ ടോക്കൺ രജിസ്റ്റർ ചെയ്യുകയോ അല്ലെങ്കിൽ കൗണ്ടറുമായി ബന്ധപ്പെടുകയോ ചെയ്യുക.",
    audit_timeline_title: "ക്യൂ ഓഡിറ്റ് ലോഗുകൾ"
  }
};
